/* ZIVOZONE V1070 — Real ZIVO AI bridge
 * Firebase AI Logic + Gemini Developer API.
 * No Gemini API key is stored in the client.
 */
import { initializeApp, getApps, getApp } from 'https://www.gstatic.com/firebasejs/12.18.0/firebase-app.js';
import { getAI, getGenerativeModel, GoogleAIBackend } from 'https://www.gstatic.com/firebasejs/12.18.0/firebase-ai.js';
import { initializeAppCheck, ReCaptchaEnterpriseProvider, getToken } from 'https://www.gstatic.com/firebasejs/12.18.0/firebase-app-check.js';

(() => {
  const cfg = window.ZIVOZONE_FIREBASE_CONFIG;
  const LIMIT = 10;
  const DAY = new Date().toISOString().slice(0, 10);
  const KEY = `zivo_ai_usage_${DAY}`;
  let chat = null;
  let model = null;
  let ready = false;
  let lastError = '';

  function usage() {
    const n = Number(localStorage.getItem(KEY) || 0);
    return Number.isFinite(n) ? n : 0;
  }
  function bump() { localStorage.setItem(KEY, String(usage() + 1)); }

  function playerContext() {
    const s = window.ZIVOZONE_STATE || window.ZIVOZONE_PLAYER || {};
    return {
      level: Number(s.level || 1),
      xp: Number(s.xp || 0),
      zivo: Number(s.coins ?? s.zivo ?? 0),
      gamesPlayed: Number(s.gamesPlayed || 0),
      wins: Number(s.wins || 0),
      bestStreak: Number(s.bestStreak || 0)
    };
  }

  function systemInstruction() {
    const lang = document.documentElement.lang === 'en' ? 'English' : 'Arabic';
    return `You are ZIVO AI, the official smart assistant inside ZIVOZONE.
Answer naturally, accurately, briefly and helpfully. Default language: ${lang}.
ZIVOZONE is a digital platform for challenges, games, sports, learning and virtual ZIVO rewards.
ZIVO is a virtual in-platform balance, not cash, an investment, or a promise of financial return.
Do not invent ZIVOZONE features, balances, rules, news, prices or account data.
When discussing the user's progress, use only the player context supplied in the current request.
Do not claim to have browsed live news unless live web/news data is actually supplied.
For medical, legal, financial or safety-critical questions, give cautious general information and recommend an appropriate qualified professional when needed.
Keep responses suitable for a broad audience and avoid collecting unnecessary personal data.`;
  }

  async function init() {
    if (!cfg?.projectId) throw new Error('Missing Firebase configuration');
    // Use the single default Firebase app. The previous build created a second
    // named app while the legacy runtime had already initialized Firebase,
    // which could result in App Check being initialized on a different app.
    let app;
    const apps = getApps();
    if (apps.length) app = getApp();
    else app = initializeApp(cfg);

    // ZIVOZONE V1070 — App Check is mandatory for Firebase AI Logic.
    // The same public reCAPTCHA Enterprise SCORE-based site key must be registered
    // for the ZIVOZONE WEB app in Firebase Console and allowed for the production domain.
    const appCheckKey = String(window.ZIVOZONE_SECURITY?.appCheckSiteKey || '').trim();
    if (!appCheckKey || appCheckKey.startsWith('<') || appCheckKey.includes('<script')) {
      throw new Error('مفتاح reCAPTCHA Enterprise غير مضبوط. تأكد أن المفتاح SCORE-based نفسه مسجل في Firebase App Check وأن نطاق الموقع مسموح في Google Cloud.');
    }

    let appCheck = window.ZIVOZONE_AI_APP_CHECK;
    if (!appCheck) {
      appCheck = initializeAppCheck(app, {
        provider: new ReCaptchaEnterpriseProvider(appCheckKey),
        isTokenAutoRefreshEnabled: true
      });
      window.ZIVOZONE_AI_APP_CHECK = appCheck;
    }

    // Do not create the AI client until a real App Check token exists.
    // This prevents the old "AppCheck: ReCAPTCHA error" from reaching AI Logic.
    let tokenResult;
    try {
      tokenResult = await getToken(appCheck, false);
      if (!tokenResult?.token) throw new Error('لم يتم إصدار App Check token.');
    } catch (firstError) {
      console.warn('ZIVO AI App Check first token attempt failed; refreshing once.', firstError);
      tokenResult = await getToken(appCheck, true);
      if (!tokenResult?.token) throw new Error('فشل إصدار App Check token. تحقق من reCAPTCHA Enterprise site key والدومين.');
    }

    window.ZIVOZONE_APP_CHECK = appCheck;
    window.ZIVOZONE_APP_CHECK_READY = true;

    const ai = getAI(app, { backend: new GoogleAIBackend() });
    model = getGenerativeModel(ai, {
      model: window.ZIVOZONE_AI_CONFIG?.model || 'gemini-3.5-flash-lite',
      systemInstruction: systemInstruction(),
      generationConfig: {
        temperature: 0.55,
        maxOutputTokens: 500
      }
    });
    chat = model.startChat();
    ready = true;
    lastError = '';
    window.dispatchEvent(new CustomEvent('zivo-ai-status', { detail: { ready: true, used: usage(), limit: LIMIT } }));
    return true;
  }

  async function ask(message) {
    const text = String(message || '').trim().slice(0, 1000);
    if (!text) return '';
    if (!navigator.onLine) throw new Error('لا يوجد اتصال بالإنترنت حاليًا.');
    if (usage() >= LIMIT) throw new Error(`وصلت إلى الحد المجاني اليومي (${LIMIT} رسائل). عد غدًا.`);
    if (!ready) await init();

    const ctx = playerContext();
    const prompt = `Player context: level=${ctx.level}, xp=${ctx.xp}, zivo=${ctx.zivo}, gamesPlayed=${ctx.gamesPlayed}, wins=${ctx.wins}, bestStreak=${ctx.bestStreak}.
User message: ${text}`;
    bump();
    const result = await chat.sendMessage(prompt);
    const reply = result?.response?.text?.() || '';
    if (!reply) throw new Error('لم يصل رد من ZIVO AI.');
    window.dispatchEvent(new CustomEvent('zivo-ai-usage', { detail: { used: usage(), limit: LIMIT } }));
    return reply.trim();
  }

  async function resetChat() {
    if (!ready) await init();
    chat = model.startChat();
  }

  window.ZIVOZONE_REAL_AI = {
    ask,
    init,
    resetChat,
    getStatus: () => ({ ready, used: usage(), limit: LIMIT, lastError })
  };

  init().catch(err => {
    lastError = err?.message || String(err);
    console.warn('ZIVO AI initialization:', err);
    window.dispatchEvent(new CustomEvent('zivo-ai-status', { detail: { ready: false, used: usage(), limit: LIMIT, error: lastError } }));
  });
})();
