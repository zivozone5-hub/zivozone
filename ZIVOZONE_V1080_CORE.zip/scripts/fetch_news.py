#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import json, re, time, urllib.parse, urllib.request, xml.etree.ElementTree as ET
from pathlib import Path
from email.utils import parsedate_to_datetime

UA="ZIVOZONE-News/3.0"

def gnews(q):
    return "https://news.google.com/rss/search?q="+urllib.parse.quote(q)+"&hl=ar&gl=JO&ceid=JO:ar"

SOURCES={
 "sports":[
  ("Google News · الرياضة العالمية",gnews("الرياضة العالمية")),
  ("Google News · كرة القدم العربية",gnews("كرة القدم العربية")),
  ("Google News · الرياضة الأردنية",gnews("كرة القدم الأردنية")),
  ("Google News · كرة القدم العالمية",gnews("كرة القدم العالمية")),
 ],
 "general":[
  ("Google News · الأردن",gnews("أخبار الأردن")),
  ("Google News · العالم العربي",gnews("أخبار عربية")),
  ("Google News · العالم",gnews("أخبار العالم")),
  ("Google News · اقتصاد",gnews("اقتصاد عربي")),
 ]
}
AR=re.compile(r"[\u0600-\u06FF]")
SPORTS=re.compile(r"كرة القدم|دوري|بطولة|منتخب|رياضة|رياضي|مباراة|مباريات|الدوري|الكأس|كأس|فيفا|يويفا|أولمبياد|تنس|سلة|سباق|فورمولا|الهلال|النصر|الوحدات|الفيصلي|الحسين|الرمثا",re.I)

def clean(s): return re.sub(r"\s+"," ",str(s or "")).strip()
def fetch(url):
    req=urllib.request.Request(url,headers={"User-Agent":UA,"Accept":"application/rss+xml, application/xml, text/xml, */*"})
    with urllib.request.urlopen(req,timeout=20) as r:return r.read()
def pub(value):
    value=clean(value)
    if not value:return ""
    try:return parsedate_to_datetime(value).isoformat()
    except Exception:return value

def parse(name,url):
    try:
        root=ET.fromstring(fetch(url)); out=[]
        for item in root.findall('.//item')[:20]:
            title=clean(item.findtext('title')); link=clean(item.findtext('link')); dt=pub(item.findtext('pubDate'))
            if title and AR.search(title):out.append({"headline":title,"source":name,"url":link,"published":dt})
        if not out:
            ns='{http://www.w3.org/2005/Atom}'
            for e in root.findall('.//'+ns+'entry')[:20]:
                title=clean((e.findtext(ns+'title'))); ln=e.find(ns+'link'); link=clean(ln.attrib.get('href','') if ln is not None else ''); dt=pub(e.findtext(ns+'published') or e.findtext(ns+'updated'))
                if title and AR.search(title):out.append({"headline":title,"source":name,"url":link,"published":dt})
        print(f"OK: {name} -> {len(out)} news")
        return out
    except Exception as e:
        print(f"Feed failed: {name} -> {e}")
        return []

def unique(xs):
    seen=set(); out=[]
    for x in xs:
        k=re.sub(r"[^\w\u0600-\u06FF]","",x['headline']).lower()
        if k and k not in seen:seen.add(k);out.append(x)
    return out

def main():
    result={"updatedAt":int(time.time()*1000),"sports":[],"general":[]}
    for group in ('sports','general'):
        items=[]
        for name,url in SOURCES[group]:items.extend(parse(name,url))
        items=unique(items)
        if group=='sports':items=[x for x in items if SPORTS.search(x['headline'])]
        else:items=[x for x in items if not SPORTS.search(x['headline'])]
        result[group]=items[:30]
        print(f"{group}: {len(result[group])} final news")
    Path('data/news.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print('ZIVOZONE NEWS UPDATED SUCCESSFULLY')
if __name__=='__main__':main()
