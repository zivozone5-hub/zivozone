import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
out=root/'data'/'matches'
idx=json.loads((out/'index.json').read_text(encoding='utf-8'))
man=json.loads((out/'manifest.json').read_text(encoding='utf-8'))
assert idx.get('version')=='1180' and man.get('version')=='1180'
assert idx.get('totalMatches',0)==man.get('totalMatches',0)
for name in man.get('days',[]):
    p=out/name; assert p.exists() and p.stat().st_size>20
    d=json.loads(p.read_text(encoding='utf-8')); assert isinstance(d.get('matches'),list)
print(f'PASS: {idx["totalMatches"]} matches across {len(man.get("days",[]))} day snapshots')
