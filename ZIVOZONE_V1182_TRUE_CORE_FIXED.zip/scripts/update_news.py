import json, re, time, urllib.request, urllib.parse, xml.etree.ElementTree as ET
from pathlib import Path
from email.utils import parsedate_to_datetime

ROOT=Path(__file__).resolve().parents[1]
SOURCES=json.loads((ROOT/'data/news-sources.json').read_text(encoding='utf-8'))
OUT=ROOT/'data/news.json'
UA='ZIVOZONE-NewsBot/1.0 (+https://zivozone.com)'

def fetch(url):
    req=urllib.request.Request(url,headers={'User-Agent':UA,'Accept':'application/rss+xml, application/xml, text/xml'})
    with urllib.request.urlopen(req,timeout=12) as r: return r.read()

def txt(el): return re.sub(r'\s+',' ', ''.join(el.itertext()) if el is not None else '').strip()
def parse(feed, source_name, category):
    root=ET.fromstring(feed); out=[]
    for item in root.findall('.//item')[:30]:
        title=txt(item.find('title')); link=txt(item.find('link')); pub=txt(item.find('pubDate'))
        if not title: continue
        try: iso=parsedate_to_datetime(pub).isoformat() if pub else ''
        except Exception: iso=''
        out.append({'headline':title,'source':source_name,'url':link,'published':iso,'category':category})
    return out

POLITICS_TERMS=re.compile(r'سياس|حكومة|وزير|وزارة|رئيس|برلمان|مجلس|انتخاب|دبلوماس|سفارة|مفاوض|اتفاق|قرار|تشريع|قانون|أمم|دولة|حزب|ائتلاف|رئاسة|قمة|اجتماع|غزة|فلسطين|إسرائيل|إيران|سوريا|لبنان|العراق|اليمن|السعودية|الأردن|أمريكا|روسيا|أوكرانيا',re.I)
SPORTS_TERMS=re.compile(r'رياض|كرة|دوري|مباراة|لاعب|نادي|بطولة|مدرب|هدف|تنس|سلة|فورمولا|فيفا|اتحاد الكرة',re.I)
NON_POLITICAL=re.compile(r'ذهب|أسعار|طقس|صحة|سمنة|مدارس|تعليم|وظائف|منوعات|تكنولوجيا',re.I)

def collect(key):
    rows=[]
    for name,url in SOURCES.get(key,[]):
        try: rows += parse(fetch(url),name,name)
        except Exception as e: print('skip',name,e)
    seen=set(); clean=[]
    for x in sorted(rows,key=lambda r:r.get('published',''),reverse=True):
        k=re.sub(r'\W+','',x['headline'].lower())
        if k and k not in seen: seen.add(k); clean.append(x)
    if key=='politics_ar':
        clean=[x for x in clean if POLITICS_TERMS.search(x.get('headline','')) and not NON_POLITICAL.search(x.get('headline','')) and not SPORTS_TERMS.search(x.get('headline',''))]
    return clean[:40]

data={'updatedAt':int(time.time()*1000),'sports':collect('google_ar')+collect('official_rss'),'politics':collect('politics_ar')}
# Deduplicate each stream and keep compact payload.
for k in ('sports','politics'):
    seen=set(); arr=[]
    for x in data[k]:
        k2=re.sub(r'\W+','',x['headline'].lower())
        if k2 not in seen: seen.add(k2); arr.append(x)
    data[k]=arr[:40]
OUT.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('updated',len(data['sports']),len(data['politics']))
