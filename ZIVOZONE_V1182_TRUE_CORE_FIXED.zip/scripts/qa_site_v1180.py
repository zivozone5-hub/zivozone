from pathlib import Path
import re, json, sys
root=Path(__file__).resolve().parents[1]
errors=[]; warnings=[]
idx=(root/'index.html').read_text(encoding='utf-8')
# local script/css/src references
for attr,pattern in [('script',r'<script[^>]+src="([^"]+)"'),('css',r'<link[^>]+href="([^"]+\.css[^\"]*)"'),('img',r'<img[^>]+src="([^"]+)"')]:
    for ref in re.findall(pattern,idx):
        if ref.startswith(('http://','https://','data:')): continue
        p=root/ref.split('?')[0].lstrip('/')
        if not p.exists(): errors.append(f'missing {attr}: {ref}')
# canonical route
if '#profile' in idx: errors.append('obsolete #profile route remains in index')
if (root/'core/modules/runtime/auth-core.js').exists(): errors.append('duplicate auth-core file remains')
# SW references
sw=(root/'sw.js').read_text(encoding='utf-8')
for ref in re.findall(r"'([^']+)'",sw):
    if ref.startswith('/') and not ref.startswith('//'):
        p=root/ref.split('?')[0].lstrip('/')
        if not p.exists(): errors.append(f'SW missing shell asset: {ref}')
# static match data
idxd=json.loads((root/'data/matches/index.json').read_text())
mand=json.loads((root/'data/matches/manifest.json').read_text())
if idxd.get('version')!='1180' or mand.get('version')!='1180': errors.append('match manifest version mismatch')
if idxd.get('totalMatches')!=mand.get('totalMatches'): errors.append('match totals mismatch')
for f in mand.get('days',[]):
    p=root/'data/matches'/f
    if not p.exists(): errors.append(f'missing match day {f}')
# syntax is delegated to node in runner
print('ZIVOZONE V1180 SITE QA')
print('local scripts checked:', len(re.findall(r'<script[^>]+src=',idx)))
print('match snapshots:', len(mand.get('days',[])), 'matches:', idxd.get('totalMatches'))
if warnings: print('WARN', *warnings, sep='\n- ')
if errors:
    print('FAIL')
    print('\n'.join('- '+e for e in errors))
    sys.exit(1)
print('PASS')
