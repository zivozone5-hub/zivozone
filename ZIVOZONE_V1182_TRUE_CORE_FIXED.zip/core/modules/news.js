/* ZIVOZONE 1127 — News Core
   Two independent broadcast rails: Football + Politics.
   Whole-headline carousel, RTL-safe, no source labels in UI.
*/
(()=>{
'use strict';
const DATA_URL='data/news.json';
const REMOTE_DATA_URL='https://raw.githubusercontent.com/zivozone5-hub/zivozone/main/data/news.json';
const CACHE_KEY='zivozone_news_core_v1127';
const REFRESH_MS=30*60*1000;
const SLIDE_MS=12000;
const esc=v=>{const d=document.createElement('div');d.textContent=String(v??'');return d.innerHTML};
const clean=v=>String(v??'').replace(/\s+/g,' ').trim();
const arabic=v=>/[\u0600-\u06FF]/.test(String(v||''));
function safeUrl(v){try{const u=new URL(String(v||''));return /^https?:$/.test(u.protocol)?u.href:''}catch(_){return ''}}
function norm(x,kind){if(!x||typeof x!=='object')return null;const headline=clean(x.headline||x.title);if(!headline||!arabic(headline))return null;return {headline,url:safeUrl(x.url),published:x.published||'',category:clean(x.category||kind)}}
function uniq(xs){const s=new Set();return xs.filter(x=>{const k=clean(x.headline).toLowerCase().replace(/[^\u0600-\u06FF\w]+/g,'');if(!k||s.has(k))return false;s.add(k);return true})}
function cacheRead(){try{return JSON.parse(localStorage.getItem(CACHE_KEY)||'null')}catch(_){return null}}
function cacheWrite(data){try{localStorage.setItem(CACHE_KEY,JSON.stringify({savedAt:Date.now(),data}))}catch(_) {}}
function item(x){const body=`<span class="zivo-news-brand">ZIVOZONE</span><span class="zivo-news-headline">${esc(x.headline)}</span>`;return x.url?`<a class="zivo-news-item" dir="rtl" href="${esc(x.url)}" target="_blank" rel="noopener noreferrer">${body}</a>`:`<span class="zivo-news-item" dir="rtl">${body}</span>`}
const timers=new Map();
function stop(id){const t=timers.get(id);if(t){clearTimeout(t);timers.delete(id)}}
function measureAndAnimate(slide){const h=slide?.querySelector('.zivo-news-headline');if(!h)return;const wrap=slide.parentElement?.parentElement;const available=wrap?.clientWidth||window.innerWidth;const overflow=Math.max(0,h.scrollWidth-(available-30));h.style.setProperty('--news-overflow',`${overflow}px`);if(overflow>12){h.classList.add('smart-scroll');const seconds=Math.max(7,Math.min(16,5+overflow/42));h.style.setProperty('--news-scroll-time',`${seconds}s`)}else h.classList.remove('smart-scroll')}
function renderRail(id,items,kind){const track=document.getElementById(id);if(!track)return;stop(id);const list=uniq(items.map(x=>norm(x,kind)).filter(Boolean)).slice(0,40);if(!list.length){track.innerHTML=`<div class="zivo-news-slide active"><span class="zivo-news-item" dir="rtl"><span class="zivo-news-brand">ZIVOZONE</span><span class="zivo-news-headline">لا توجد أخبار ${kind==='politics'?'سياسية':'رياضية'} متاحة الآن.</span></span></div>`;return}
 let index=0;track.innerHTML=`<div class="zivo-news-slide active">${item(list[0])}</div>`;let current=track.firstElementChild;
 const tick=()=>{index=(index+1)%list.length;const next=document.createElement('div');next.className='zivo-news-slide next';next.innerHTML=item(list[index]);track.appendChild(next);requestAnimationFrame(()=>{requestAnimationFrame(()=>{measureAndAnimate(next);current.className='zivo-news-slide orbit-out';next.className='zivo-news-slide active'})});const old=current;current=next;setTimeout(()=>old.remove(),1900);const timer=setTimeout(tick,SLIDE_MS);timers.set(id,timer)};
 requestAnimationFrame(()=>measureAndAnimate(current));timers.set(id,setTimeout(tick,SLIDE_MS));
}
function render(data){renderRail('z50track',data?.sports||[],'sports');renderRail('zivoGeneralTrack',data?.politics||[],'politics');window.dispatchEvent(new CustomEvent('zivozone:news-updated',{detail:data||{}}))}
async function fetchData(url){const c=new AbortController(),t=setTimeout(()=>c.abort(),8000);try{const r=await fetch(`${url}${url.includes('?')?'&':'?'}v=${Date.now()}`,{cache:'no-store',signal:c.signal});if(!r.ok)throw Error(r.status);const d=await r.json();return {updatedAt:Number(d.updatedAt)||Date.now(),sports:Array.isArray(d.sports)?d.sports:[],politics:Array.isArray(d.politics)?d.politics:[]}}finally{clearTimeout(t)}}
async function load(){const cached=cacheRead();let local=null;try{local=await fetchData(DATA_URL);if(local?.sports?.length||local?.politics?.length){cacheWrite(local);render(local)}}catch(_){if(cached?.data)render(cached.data)}try{const remote=await fetchData(REMOTE_DATA_URL);if(remote&&(remote.sports?.length||remote.politics?.length)&&Number(remote.updatedAt)>=Number(local?.updatedAt||0)){cacheWrite(remote);render(remote);return remote}}catch(e){console.warn('News refresh',e)}if(local)return local;if(cached?.data)return cached.data;render({sports:[],politics:[]});return null}
window.ZIVOZONE_NEWS={load,loadJordan:load,refresh:load,version:'1127'};window.ZIVOZONE_SPORTS_TICKER={load,refresh:load};document.addEventListener('DOMContentLoaded',()=>setTimeout(load,120));setInterval(load,REFRESH_MS);window.addEventListener('resize',()=>document.querySelectorAll('.zivo-news-slide.active').forEach(measureAndAnimate));
})();
