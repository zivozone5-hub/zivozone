/* ZIVOZONE V1180 — Canonical Economy Core
   Wallet + Mining + Rewards + Ledger in one in-site service.
   No dependency on the legacy ZIVOZONE_ECONOMY runtime.
*/
(() => {
  'use strict';

  const F = () => window.firebase;
  const auth = () => { try { return F()?.auth?.() || null; } catch (_) { return null; } };
  const db = () => { try { return F()?.firestore?.() || null; } catch (_) { return null; } };
  const user = () => auth()?.currentUser || null;
  const cfg = () => window.ZIVOZONE_CONFIG || {};
  const t = (key) => { try { return window.zivoT ? window.zivoT(key) : (window.ZIVOZONE_I18N?.tr?.(key) || key); } catch (_) { return key; } };
  const num = (v) => Math.max(0, Number(v) || 0);
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));

  const state = { uid: null, zivo: 0, ledger: [], nextMiningAt: 0, loading: false };
  const cooldown = () => Number(cfg().MINING_COOLDOWN_MS) || 86400000;
  const admin = (u = user()) => !!u && String(u.email || '').toLowerCase() === String(cfg().ADMIN_EMAIL_NORMALIZED || cfg().ADMIN_EMAIL || '').toLowerCase();
  const root = (uid) => db().collection('users').doc(uid).collection('zivozone');

  function toast(msg) {
    let x = document.getElementById('zivo-economy-toast');
    if (!x) { x = document.createElement('div'); x.id = 'zivo-economy-toast'; x.className = 'z101-toast'; document.body.appendChild(x); }
    x.textContent = msg;
    x.classList.add('show');
    clearTimeout(x._timer);
    x._timer = setTimeout(() => x.classList.remove('show'), 2600);
  }

  async function ensureWallet(u = user()) {
    const d = db(); if (!u || !d) return false;
    const ref = root(u.uid).doc('wallet');
    const snap = await ref.get();
    if (!snap.exists) {
      const fv = F().firestore.FieldValue;
      await ref.set({ zivo: 0, createdAt: fv.serverTimestamp(), updatedAt: fv.serverTimestamp(), mode: 'zivozone-economy-v1180' }, { merge: false });
    }
    return true;
  }

  async function refresh() {
    const u = user(); state.uid = u?.uid || null;
    if (!u) {
      state.zivo = 0; state.ledger = []; state.nextMiningAt = 0; syncUI(); return { ...state };
    }
    const d = db(); if (!d) { syncUI(); return { ...state }; }
    try {
      await ensureWallet(u);
      const r = root(u.uid), wallet = r.doc('wallet');
      const [ws, ls, ms] = await Promise.all([
        wallet.get(),
        wallet.collection('ledger').orderBy('createdAt', 'desc').limit(25).get().catch(() => null),
        r.doc('mining').get().catch(() => null)
      ]);
      state.zivo = num(ws.data()?.zivo);
      state.ledger = ls ? ls.docs.map(x => ({ id: x.id, ...x.data() })) : [];
      const ts = ms?.data()?.nextMiningAt;
      state.nextMiningAt = ts?.toMillis ? ts.toMillis() : num(ts);
    } catch (e) { console.warn('ZIVO Economy refresh:', e); }
    syncUI();
    return { ...state, ledger: [...state.ledger] };
  }

  function formatBalance(value) {
    const n = Number(value) || 0;
    return Number.isInteger(n) ? String(n) : n.toFixed(2).replace(/0+$/, '').replace(/\.$/, '');
  }

  function syncUI() {
    const bal = `${formatBalance(state.zivo)} ZIVO`;
    document.querySelectorAll('#z101-balance,[data-v101-balance],#zivo-hub-balance').forEach(x => x.textContent = bal);

    const u = user();
    const status = document.getElementById('z101-wallet-status');
    if (status) status.textContent = u
      ? `حسابك متصل • الرصيد محفوظ على Firebase`
      : 'سجّل الدخول لحفظ رصيدك ومكافآتك';

    const last = [...state.ledger].find(x => x.type === 'daily_mining');
    const lastNode = document.getElementById('z101-last-mining');
    if (lastNode) lastNode.textContent = last?.createdAt?.toDate
      ? `آخر تعدين: ${last.createdAt.toDate().toLocaleString('ar-JO', { dateStyle:'short', timeStyle:'short' })}`
      : 'لم يتم التعدين بعد';

    updateMiningUI();
    renderLedgerPreview();
    updateHeaderEconomy();
  }


  function updateHeaderEconomy() {
    const chip = document.getElementById('zivo-header-economy');
    if (chip) {
      const balance = chip.querySelector('[data-header-balance]');
      if (balance) balance.textContent = formatBalance(state.zivo);
    }
    const mineBtn = document.getElementById('zivo-header-mining');
    if (mineBtn) {
      const u = user();
      const left = Math.max(0, (state.nextMiningAt || 0) - Date.now());
      mineBtn.disabled = !u || left > 0;
      mineBtn.classList.toggle('ready', !!u && left <= 0);
      mineBtn.querySelector('[data-mining-label]')?.replaceChildren(document.createTextNode(left <= 0 ? '⛏ تعدين +0.50' : `⏳ ${formatMs(left)}`));
      mineBtn.title = !u ? 'سجّل الدخول للتعدين' : left <= 0 ? 'التعدين متاح الآن' : `التعدين القادم بعد ${formatMs(left)}`;
    }
  }

  function updateMiningUI() {
    const b = document.getElementById('z101-mine'), c = document.getElementById('z101-countdown');
    const progress = document.getElementById('z101-mining-progress');
    const cycle = cooldown();
    const u = user();
    const left = Math.max(0, (state.nextMiningAt || 0) - Date.now());
    if (b && c) {
      if (!u) {
        b.textContent = 'تسجيل الدخول'; b.disabled = false; c.textContent = 'يلزم حساب ZIVOZONE'; c.classList.remove('z101-ready'); if(progress)progress.style.width='0%';
      } else if (left <= 0) {
        b.textContent = '⛏️ ابدأ التعدين +0.50'; b.disabled = false; c.textContent = 'متاح الآن — مكافأة 0.50 ZIVO'; c.classList.add('z101-ready'); if(progress)progress.style.width='100%';
      } else {
        b.textContent = '⏳ التعدين القادم'; b.disabled = true; c.textContent = `متاح بعد ${formatMs(left)}`; c.classList.remove('z101-ready'); const elapsed=Math.max(0,cycle-left); if(progress)progress.style.width=`${Math.min(100,Math.max(0,elapsed/cycle*100))}%`;
      }
      const badge=document.getElementById('z101-mining-badge'); if(badge)badge.textContent=left<=0?'جاهز':'24 ساعة';
    }
    const mineBtn=document.getElementById('zivo-header-mining');
    if(mineBtn){
      const label=mineBtn.querySelector('[data-mining-label]');
      const ready=!!u&&left<=0;
      mineBtn.disabled=!!u&&left>0;
      mineBtn.classList.toggle('ready',ready);
      if(label) label.textContent=ready?'⛏ تعدين +0.50':(!u?'⛏ تعدين':`⏳ ${formatMs(left)}`);
      mineBtn.title=!u?'سجّل الدخول للتعدين':ready?'التعدين متاح الآن':`التعدين القادم بعد ${formatMs(left)}`;
    }
  }

  function formatMs(ms) {
    const s = Math.floor(ms / 1000), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
    return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
  }

  async function mine() {
    const u = user(), d = db();
    if (!u) { document.querySelector('#login-btn,[data-action="login"]')?.click(); return false; }
    if (!d) { toast('تعذر الاتصال بـ Firebase'); return false; }
    const button = document.getElementById('z101-mine');
    if (button) { button.disabled = true; button.textContent = '⏳ جارٍ تسجيل التعدين…'; }
    try {
      const r = root(u.uid), wallet = r.doc('wallet'), mining = r.doc('mining');
      const claimKey = `${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
      const ledger = wallet.collection('ledger').doc(`mining_${claimKey}`);
      await d.runTransaction(async tx => {
        const [ws, ms] = await Promise.all([tx.get(wallet), tx.get(mining)]);
        const previous = ms.exists ? ms.data()?.nextMiningAt : null;
        const prevMs = previous?.toMillis?.() || Number(previous) || 0;
        const now = Date.now();
        if (prevMs > now) { const e = new Error('not_yet_available'); e.code = 'MINE_NOT_YET'; throw e; }
        const current = num(ws.data()?.zivo), fv = F().firestore.FieldValue;
        const nextAt = new Date(now + cooldown() + 5000);
        tx.set(wallet, { zivo: current + 0.5, updatedAt: fv.serverTimestamp(), mode: 'zivozone-economy-v1180' }, { merge: true });
        tx.set(mining, { lastMiningAt: fv.serverTimestamp(), nextMiningAt: nextAt, amount: 0.5, version: 'v1180' }, { merge: true });
        tx.set(ledger, { type:'daily_mining', label:'التعدين اليومي', amount:0.5, eventId:ledger.id, createdAt:fv.serverTimestamp(), source:'zivozone-v1127', policy:'24h_mining' });
      });
      await refresh();
      toast('تم التعدين بنجاح +0.50 ZIVO');
      return true;
    } catch (e) {
      console.warn('ZIVO mining:', e);
      toast(e?.code === 'MINE_NOT_YET' ? 'التعدين غير متاح بعد' : 'تعذر تسجيل التعدين. تحقق من تسجيل الدخول والاتصال.');
      await refresh();
      return false;
    }
  }

  function renderLedgerPreview() {
    const node = document.getElementById('z101-ledger-preview');
    if (!node) return;
    if (!state.ledger.length) {
      node.innerHTML = '<span>لا توجد عمليات بعد</span>';
      return;
    }
    node.innerHTML = state.ledger.slice(0,3).map(x => {
      const amount = Number(x.amount) || 0;
      const label = x.type === 'daily_mining' ? '⛏️ تعدين يومي' : x.type === 'challenge_reward' ? '🏆 تحدٍ كامل' : (x.label || x.type || 'عملية');
      return `<div class="z101-ledger-mini"><span>${esc(label)}</span><b>+${formatBalance(amount)}</b></div>`;
    }).join('');
  }

  function open() {
    let o = document.getElementById('zivo-economy-modal');
    if (!o) {
      o = document.createElement('div'); o.id = 'zivo-economy-modal'; o.className = 'z101-overlay';
      document.body.appendChild(o);
      o.addEventListener('click', e => { if (e.target === o) o.classList.remove('open'); });
    }
    const locale = document.documentElement.lang === 'ar' ? 'ar-JO' : (document.documentElement.lang || 'en');
    o.innerHTML = `<div class="z101-modal" dir="${document.documentElement.dir || 'rtl'}">
      <div class="z101-modal-head"><div><div class="z101-label">ZIVO HUB</div><h2>محفظة ZIVO</h2></div><button class="z101-modal-close" aria-label="إغلاق">×</button></div>
      <div id="z101-modal-balance" class="z101-modal-balance">${formatBalance(state.zivo)} ZIVO</div>
      <div class="z101-modal-stats"><span><b>${state.ledger.length}</b> عمليات</span><span><b>0.50</b> ZIVO / تعدين</span></div>
      <div class="z101-ledger"><div class="z101-ledger-title">آخر العمليات</div><div id="z101-modal-ledger" class="z101-ledger-list"></div></div>
      <div class="z101-note">ZIVO رصيد افتراضي للاستخدام داخل ZIVOZONE فقط.</div>
    </div>`;
    o.querySelector('.z101-modal-close').onclick = () => o.classList.remove('open');
    o.querySelector('#z101-modal-ledger').innerHTML = state.ledger.length
      ? state.ledger.map(x => `<div class="z101-ledger-row"><span>${esc(x.label || (x.type === 'daily_mining' ? 'التعدين اليومي' : x.type))}</span><b>+${formatBalance(x.amount)}</b><small>${x.createdAt?.toDate ? x.createdAt.toDate().toLocaleString(locale) : '—'}</small></div>`).join('')
      : '<p>لا توجد عمليات بعد.</p>';
    o.classList.add('open');
  }

  function mountHeaderEconomy() {
    const actions = document.querySelector('.topbar .top-actions');
    if (!actions) return;
    if (!document.getElementById('zivo-header-economy')) {
      const chip = document.createElement('button');
      chip.id = 'zivo-header-economy'; chip.type='button'; chip.className='zivo-header-economy';
      chip.setAttribute('aria-label','فتح محفظة ZIVO');
      chip.innerHTML = `<span class="zivo-header-coin">Z</span><span class="zivo-header-balance"><small>ZIVO</small><b data-header-balance>0</b></span>`;
      chip.onclick = open;
      const login = document.getElementById('login-btn'); actions.insertBefore(chip, login || null);
    }
    if (!document.getElementById('zivo-header-mining')) {
      const mineBtn=document.createElement('button');
      mineBtn.id='zivo-header-mining'; mineBtn.type='button'; mineBtn.className='zivo-header-mining-btn';
      mineBtn.innerHTML='<span data-mining-label>⛏ تعدين +0.50</span>';
      mineBtn.addEventListener('click',()=>mine());
      const login=document.getElementById('login-btn'); actions.insertBefore(mineBtn, login || null);
    }
  }

  function mountHub() {
    if (document.getElementById('zivo-economy-core')) return;
    const anchor = document.getElementById('home'); if (!anchor) return;
    const rootEl = document.createElement('section');
    rootEl.id = 'zivo-economy-core';
    rootEl.className = 'zivo-economy-core zivo-wallet-only';
    rootEl.setAttribute('aria-label','ZIVO Wallet — المحفظة');
    rootEl.innerHTML = `<div class="zivo-economy-head"><div><span class="zivo-economy-kicker">ZIVO ECONOMY</span><h2>محفظة ZIVO</h2><p>رصيدك ومكافآتك في مكان واحد. التعدين متاح من زر مستقل في الشريط العلوي.</p></div><div class="zivo-economy-total"><span>الرصيد الحالي</span><strong id="zivo-hub-balance">0 ZIVO</strong></div></div><div class="zivo-economy-grid zivo-economy-single"><article class="zivo-economy-card zivo-wallet-card"><div class="zivo-card-icon zivo-coin-icon">Z</div><div class="zivo-card-main"><span class="zivo-card-label">محفظة ZIVO</span><strong id="z101-balance">0 ZIVO</strong><small id="z101-wallet-status">سجّل الدخول لحفظ رصيدك ومكافآتك</small></div><button id="z101-wallet-open" class="zivo-economy-btn secondary">فتح المحفظة</button></article></div><div class="zivo-economy-foot"><div><b>آخر العمليات</b><div id="z101-ledger-preview" class="z101-ledger-preview"><span>جارٍ التحميل…</span></div></div><span class="zivo-economy-security">🔒 معاملات ZIVO محفوظة في Firebase</span></div>`;
    anchor.insertAdjacentElement('afterend', rootEl);
    rootEl.querySelector('#z101-wallet-open').onclick = open;
    window.addEventListener('zivozone-language', syncUI);
    mountHeaderEconomy();
  }

  function bind() {
    mountHub();
    mountHeaderEconomy();
    auth()?.onAuthStateChanged?.(() => setTimeout(refresh, 100));
    refresh();
    setInterval(() => { if (document.visibilityState === 'visible') refresh(); }, 30000);
    setInterval(updateMiningUI, 1000);
  }

  const processed = new Set();
  // ── Reward Engine (spec §12): Reward Engine → Economy → Ledger → Wallet →
  // State → UI. Single credit primitive, idempotent by claimId, used by every
  // reward source (mining already has its own transaction above; this one is
  // for missions/competition/challenge rewards).
  async function credit(amount, meta = {}) {
    const u = user(), d = db();
    const value = Number(amount) || 0;
    if (!u || !d || value <= 0) return false;

    // One reward contract for every non-mining reward:
    // claim -> wallet -> ledger, committed in ONE Firestore transaction.
    // This keeps Economy and Security Rules on the same data model and makes
    // duplicate event delivery harmless.
    const type = String(meta.type || 'reward');
    const policy = type === 'challenge_reward' ? '10_of_10_only'
      : type === 'mission_reward' ? 'mission_reward'
      : type === 'competition_reward' ? 'competition_reward' : '';
    const allowed = type === 'challenge_reward' ? value === 10
      : type === 'mission_reward' ? [1,2].includes(value)
      : type === 'competition_reward' ? [1,5].includes(value) : false;
    if (!policy || !allowed) return false;

    try {
      const r = root(u.uid), wallet = r.doc('wallet');
      await ensureWallet(u);
      const rawClaim = String(meta.claimId || meta.eventId || meta.attemptId || `${type}_${Date.now()}_${Math.random().toString(36).slice(2,8)}`);
      const claimId = rawClaim.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 140) || `reward_${Date.now()}`;
      const claimRef = r.collection('rewardClaims').doc(claimId);
      const ledgerRef = wallet.collection('ledger').doc(claimId);

      await d.runTransaction(async tx => {
        const [claimSnap, ledgerSnap, ws] = await Promise.all([
          tx.get(claimRef), tx.get(ledgerRef), tx.get(wallet)
        ]);
        if (claimSnap.exists || ledgerSnap.exists) return;

        const current = num(ws.data()?.zivo);
        const fv = F().firestore.FieldValue;
        const claim = {
          claimId,
          type,
          amount: value,
          status: 'consumed',
          consumedAt: fv.serverTimestamp(),
          policy,
          total: type === 'challenge_reward' ? 10 : null,
          correct: type === 'challenge_reward' ? 10 : null,
          timedOut: type === 'challenge_reward' ? 0 : null,
          challenge: meta.challenge || null,
          mission: meta.mission || null,
          competition: meta.competition || null
        };
        tx.set(claimRef, claim);
        tx.set(wallet, {
          zivo: current + value,
          updatedAt: fv.serverTimestamp(),
          lastRewardClaimId: claimId,
          mode: 'zivozone-economy-v1180'
        }, { merge: true });
        tx.set(ledgerRef, {
          type, label: meta.label || 'مكافأة', amount: value,
          source: meta.source || 'economy', eventId: claimId,
          createdAt: fv.serverTimestamp(), claimId,
          challenge: meta.challenge || null,
          mission: meta.mission || null,
          competition: meta.competition || null
        });
      });
      await refresh();
      return true;
    } catch (e) {
      console.warn('ZIVO Economy credit:', e);
      return false;
    }
  }

  async function addXP(amount) {
    try { window.ZIVOZONE?.Player?.addXP?.(Number(amount) || 0); return true; }
    catch (e) { console.warn('ZIVO Economy addXP:', e); return false; }
  }

  // Called directly by challenges.js on a perfect 10/10 round (spec §13).
  async function rewardChallenge({ challengeId, amount, eventId } = {}) {
    const u = user();
    if (!u || admin(u)) return false; // admin test account never accrues challenge rewards
    const value = Number(amount) || 0;
    if (value <= 0) return false;
    const claimId = eventId || `challenge_${challengeId || 'x'}_${Date.now()}`;
    const ok = await credit(value, {
      type: 'challenge_reward', label: '🏆 مكافأة تحدٍ كامل 10/10', source: 'challenge',
      challenge: challengeId, claimId
    });
    if (ok) toast(`🏆 مكافأة تحدٍ كامل +${formatBalance(value)} ZIVO`);
    return ok;
  }

  // Kept for the DOM-event listener path below (onChallenge). Converges on
  // the same claimId as rewardChallenge() so a round that fires both paths
  // is only ever credited once (Final Acceptance §63: no double reward).
  async function rewardPerfect(d = {}) {
    return rewardChallenge({
      challengeId: d.challenge || d.gameId,
      amount: Number(d.zivoReward ?? d.coins ?? 10) || 10,
      eventId: d.eventId || d.attemptId
    });
  }

  function onChallenge(e) {
    const d = e?.detail || {};
    const total = Number(d.total ?? d.questions) || 0, correct = Number(d.correct ?? d.score) || 0;
    if (!user() || admin() || total !== 10 || correct !== 10 || Number(d.timedOut || 0) !== 0 || d.perfect !== true) return;
    const eventId = String(d.eventId || '').replace(/[^a-zA-Z0-9_-]/g,'').slice(0,100);
    if (!eventId || processed.has(eventId)) return;
    processed.add(eventId);
    rewardPerfect({ ...d, total:10, correct:10, timedOut:0, attemptId:eventId, eventId });
  }
  ['zivozone-result','zivozone-progress','zivozone:game-complete','zivozone:challenge-result','zivozone:progress-updated'].forEach(n => addEventListener(n, onChallenge, true));

  window.ZIVOZONE = window.ZIVOZONE || {};
  window.ZIVOZONE.Economy = Object.freeze({
    open, refresh, getWallet: () => ({ ...state, ledger: [...state.ledger] }), mine,
    rewardPerfect, rewardChallenge, credit, addXP,
    status: () => ({ legacy:false, cloud:!!user(), admin:admin(), version: '1180' })
  });
  window.ZIVOZONE.EconomyVersion = '1141-unified-reward-contract';
  window.dispatchEvent(new CustomEvent('zivozone:module-ready', { detail:{ module:'economy', version: '1180' } }));
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setTimeout(bind, 50)); else setTimeout(bind, 50);
})();
