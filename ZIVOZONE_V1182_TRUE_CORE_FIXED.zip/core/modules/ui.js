/* ZIVOZONE V1180 — Canonical UI module */
(() => {
  'use strict';
  const api = {
    toast(message, ms=2800) {
      if (typeof window.toast === 'function') return window.toast(message);
      const node=document.createElement('div');
      node.className='zivo-1096-toast';
      node.textContent=String(message ?? '');
      document.body.appendChild(node);
      setTimeout(()=>node.remove(),ms);
    },
    modal(selector) { return document.querySelector(selector); },
    navigate(hash) { if (typeof hash === 'string') window.location.hash = hash.startsWith('#') ? hash : '#'+hash; }
  };
  window.ZIVOZONE = window.ZIVOZONE || {};
  window.ZIVOZONE.UI = Object.freeze(api);
  window.dispatchEvent(new CustomEvent('zivozone:module-ready',{detail:{module:'ui',version:'1096'}}));
})();
