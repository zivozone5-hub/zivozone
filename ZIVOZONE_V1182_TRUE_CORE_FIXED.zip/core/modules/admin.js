/* ZIVOZONE V1180 — ADMIN COMMAND CENTER CORE
   Owner-only operational dashboard. Reads existing Firestore data without Cloud Functions.
*/
(()=>{'use strict';
 const ADMIN=()=>String(window.ZIVOZONE_CONFIG?.ADMIN_EMAIL_NORMALIZED||'').trim().toLowerCase();
 const auth=()=>window.firebase?.auth?.(); const db=()=>window.firebase?.firestore?.();
 const owner=()=>String(auth()?.currentUser?.email||'').trim().toLowerCase()===ADMIN();
 const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
 const ms=v=>v?.toMillis?.()||(typeof v==='string'?Date.parse(v)||0:Number(v)||0);
 const fmt=v=>v?new Date(v).toLocaleString('ar-JO',{dateStyle:'medium',timeStyle:'short'}):'—';
 const safe=async(fn,fall)=>{try{return await fn()}catch(e){console.warn('Admin Core',e);return fall}};
 async function collect(){
  if(!owner())throw Error('ADMIN ONLY'); const d=db(); if(!d)throw Error('Firebase unavailable');
  const [us,ps,vis]=await Promise.all([
   safe(()=>d.collection('users').limit(500).get(),null),safe(()=>d.collection('players').limit(500).get(),null),
   safe(()=>{const day=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Amman'}).format(new Date());return d.collection('siteStats').doc('visitors').collection(day).limit(1000).get()},null)
  ]);
  const users=(us?.docs||[]).map(x=>({uid:x.id,...x.data()})).filter(x=>String(x.email||'').trim().toLowerCase()!==ADMIN());
  const players=(ps?.docs||[]).map(x=>({uid:x.id,...x.data()})).filter(x=>String(x.email||'').trim().toLowerCase()!==ADMIN());
  const pm=new Map(players.map(p=>[p.uid,p]));
  const rows=users.map(u=>{const p=pm.get(u.uid)||{};return {uid:u.uid,name:u.name||p.name||'ZIVO Player',email:u.email||p.email||'',role:u.role||p.role||'player',level:+(p.level??u.level??1)||1,xp:+(p.xp??u.xp??0)||0,zivo:+(u.zivo??p.zivo??u.coins??p.coins??0)||0,games:+(p.gamesPlayed??u.gamesPlayed??0)||0,wins:+(p.wins??u.wins??0)||0,last:ms(u.lastSeenAt||p.lastSeenAt||u.updatedAt||p.updatedAt),path:u.lastSeenPath||p.lastSeenPath||'#home',created:ms(u.createdAt||p.createdAt),active:+(u.engagement?.activeMinutes??p.activeMinutes??0)||0,terms:u.termsVersion||'—'}}).sort((a,b)=>b.last-a.last);
  let activity=[],ledgerTotal=0,miningCount=0,challengeCount=0,perfectCount=0;
  await Promise.all(rows.slice(0,80).map(async r=>{const base=d.collection('users').doc(r.uid),pbase=d.collection('players').doc(r.uid);const [ac,wl,mi,lg,res,attempts]=await Promise.all([
    safe(()=>base.collection('activity').limit(15).get(),null),safe(()=>base.collection('zivozone').doc('wallet').get(),null),safe(()=>base.collection('zivozone').doc('mining').get(),null),safe(()=>base.collection('zivozone').doc('wallet').collection('ledger').limit(50).get(),null),safe(()=>pbase.collection('results').limit(50).get(),null),safe(()=>pbase.collection('attempts').limit(30).get(),null)]);
    ac?.docs.forEach(x=>activity.push({uid:r.uid,name:r.name,...x.data(),time:ms(x.data()?.createdAt)}));
    if(wl?.exists)r.zivo=+(wl.data()?.zivo??r.zivo)||0;
    (lg?.docs||[]).forEach(x=>{const a=+x.data()?.amount||0;ledgerTotal+=a;if(x.data()?.type==='daily_mining')miningCount++;if(x.data()?.type==='challenge_reward')perfectCount++});
    challengeCount+=(res?.size||0)+(attempts?.size||0);
    r.nextMiningAt=ms(mi?.data()?.nextMiningAt);
  }));
  activity.sort((a,b)=>b.time-a.time);
  const now=Date.now(),dayStart=new Date();dayStart.setHours(0,0,0,0);
  return {rows,activity:activity.slice(0,120),stats:{users:rows.length,players:players.length,visitors:vis?.size||0,active:rows.filter(r=>r.last&&now-r.last<=10*60*1000).length,today:rows.filter(r=>r.last>=dayStart.getTime()).length,games:rows.reduce((n,r)=>n+r.games,0),wins:rows.reduce((n,r)=>n+r.wins,0),zivo:rows.reduce((n,r)=>n+r.zivo,0),ledgerTotal,miningCount,perfectCount,challengeCount,online:navigator.onLine,domain:location.hostname,refreshedAt:Date.now()}};
 }
 function render(x){
  let o=document.getElementById('zivo-admin-core');if(!o){o=document.createElement('div');o.id='zivo-admin-core';o.className='zivo-admin-core';document.body.appendChild(o)}
  const s=x.stats,r=x.rows,a=x.activity,max=Math.max(1,s.users,s.games,s.challengeCount,s.miningCount);
  const k=(v,n,h)=>`<div class="zac-kpi"><b>${esc(v)}</b><span>${esc(n)}</span><small>${esc(h)}</small></div>`;
  const users=r.map(u=>`<div class="zac-user"><b>${esc(u.name)}</b><span>${esc(u.email)}</span><span>Lv ${u.level}</span><span>${u.xp} XP</span><span>🪙 ${u.zivo.toFixed(2)}</span><span>${u.games}</span><span>${u.wins}</span><span class="${u.last&&Date.now()-u.last<600000?'online':''}">${u.last?fmt(u.last):'—'}</span><span>${esc(u.path)}</span></div>`).join('')||'<div class="zac-empty">لا يوجد مستخدمون مسجلون حتى الآن.</div>';
  const acts=a.map(v=>`<div class="zac-activity"><b>${esc(v.name||'مستخدم')}</b><span>${esc(v.event||v.type||'نشاط داخل المنصة')}</span><small>${esc(v.meta?.path||v.path||'#home')} · ${fmt(v.time)}</small></div>`).join('')||'<div class="zac-empty">لا يوجد نشاط محفوظ.</div>';
  o.innerHTML=`<div class="zac-shell" dir="rtl"><header class="zac-head"><div class="zac-brand">Z</div><div><small>OWNER OPERATIONS • ZIVOZONE CORE</small><h2>مركز التحكم الإداري</h2><p>${esc(ADMIN())}</p></div><div class="zac-live">● LIVE MONITORING</div><button class="zac-close">×</button></header><main class="zac-body"><section class="zac-kpis">${k(s.users,'المستخدمون','حسابات غير إدارية')}${k(s.visitors,'زوار اليوم','Visitor telemetry')}${k(s.active,'نشط الآن','آخر 10 دقائق')}${k(s.today,'نشط اليوم','آخر ظهور')}${k(s.games,'إجمالي الألعاب','Saved player data')}${k(s.challengeCount,'محاولات التحديات','Results + attempts')}${k(s.miningCount,'عمليات التعدين','Ledger')}${k(s.zivo.toFixed(2),'إجمالي ZIVO','Virtual economy')}</section><section class="zac-grid"><section class="zac-panel"><div class="zac-title"><div><h3>👥 المستخدمون — LIVE</h3><small>الحساب · المستوى · XP · ZIVO · الألعاب · آخر صفحة</small></div><button class="zac-refresh">↻ تحديث</button></div><div class="zac-users"><div class="zac-user head"><b>الاسم</b><span>البريد</span><span>Lv</span><span>XP</span><span>ZIVO</span><span>ألعاب</span><span>فوز</span><span>آخر ظهور</span><span>المسار</span></div>${users}</div></section><aside class="zac-panel"><div class="zac-title"><div><h3>⚡ النشاط التشغيلي</h3><small>آخر الأحداث المحفوظة</small></div></div><div class="zac-activities">${acts}</div></aside></section><section class="zac-grid bottom"><section class="zac-panel"><div class="zac-title"><div><h3>📊 مؤشرات الاستخدام</h3><small>قراءة تشغيلية سريعة</small></div></div><div class="zac-bars">${[['المستخدمون',s.users],['الألعاب',s.games],['التحديات',s.challengeCount],['التعدين',s.miningCount]].map(([n,v])=>`<div><span>${n}</span><i><em style="width:${Math.min(100,v/max*100)}%"></em></i><b>${v}</b></div>`).join('')}</div></section><section class="zac-panel"><div class="zac-title"><div><h3>🛰️ صحة المنصة</h3><small>الحالة الفعلية للعميل</small></div></div><div class="zac-health"><div>Firebase<b>${db()?'CONNECTED':'OFFLINE'}</b></div><div>Hosting<b>${navigator.onLine?'ONLINE':'OFFLINE'}</b></div><div>Domain<b>${esc(s.domain)}</b></div><div>Ledger ZIVO<b>${s.ledgerTotal.toFixed(2)}</b></div><div>Perfect rewards<b>${s.perfectCount}</b></div><div>آخر تحديث<b>${fmt(s.refreshedAt)}</b></div></div></section></section></main></div>`;
  o.querySelector('.zac-close').onclick=close;o.querySelector('.zac-refresh').onclick=async e=>{e.currentTarget.disabled=true;e.currentTarget.textContent='جارٍ…';try{render(await collect())}finally{e.currentTarget.disabled=false;e.currentTarget.textContent='↻ تحديث'}};
 }
 function close(){document.getElementById('zivo-admin-core')?.remove();clearInterval(timer)}
 let timer=0;
 async function open(){if(!owner()){alert('هذا الحساب ليس حساب الإدارة.');return}try{render(await collect());clearInterval(timer);timer=setInterval(async()=>{if(document.getElementById('zivo-admin-core'))try{render(await collect())}catch(e){}},20000)}catch(e){console.error(e);alert('تعذر تحميل مركز الإدارة. تحقق من Firebase Rules.')}}
 function bind(){const b=document.getElementById('login-btn');if(b&&owner()){b.textContent='👑 ADMIN';b.setAttribute('aria-label','مركز التحكم الإداري')}}
 document.addEventListener('click',e=>{const b=e.target.closest('#login-btn');if(b&&owner()){e.preventDefault();e.stopImmediatePropagation();open()}},true);
 window.ZIVOZONE=window.ZIVOZONE||{};window.ZIVOZONE.Admin=Object.freeze({open,collect});window.ZIVOZONE_MONITOR=Object.freeze({open,adminData:collect});
 window.addEventListener('zivozone-auth',()=>setTimeout(bind,300));if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bind);else bind();
})();
