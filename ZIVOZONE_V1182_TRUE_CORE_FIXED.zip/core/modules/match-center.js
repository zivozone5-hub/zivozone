/* ZIVOZONE V1180 — GLOBAL COMPETITION MATCH CORE
   Rebuilt from the live ESPN connection in V1180.
   Structure: Competition -> Day -> Matches -> Live State -> Details.
   No old runtime references, no fake fixtures, no generated fixture dependency.
*/
(()=>{'use strict';
const VERSION='1182';
const API='https://site.api.espn.com/apis/site/v2/sports/soccer/';
const STATIC='./data/matches/';
const TZ='Asia/Amman';
const LEAGUES=[
{id:'uefa.champions',ar:'دوري أبطال أوروبا',icon:'⭐',group:'البطولات القارية',priority:1},
{id:'eng.1',ar:'الدوري الإنجليزي الممتاز',icon:'🏴',group:'أوروبا',priority:2},
{id:'esp.1',ar:'الدوري الإسباني',icon:'🇪🇸',group:'أوروبا',priority:3},
{id:'ita.1',ar:'الدوري الإيطالي',icon:'🇮🇹',group:'أوروبا',priority:4},
{id:'ger.1',ar:'الدوري الألماني',icon:'🇩🇪',group:'أوروبا',priority:5},
{id:'fra.1',ar:'الدوري الفرنسي',icon:'🇫🇷',group:'أوروبا',priority:6},
{id:'ned.1',ar:'الدوري الهولندي',icon:'🇳🇱',group:'أوروبا',priority:7},
{id:'por.1',ar:'الدوري البرتغالي',icon:'🇵🇹',group:'أوروبا',priority:8},
{id:'tur.1',ar:'الدوري التركي',icon:'🇹🇷',group:'أوروبا',priority:9},
{id:'bra.1',ar:'الدوري البرازيلي',icon:'🇧🇷',group:'أمريكا الجنوبية',priority:10},
{id:'arg.1',ar:'الدوري الأرجنتيني',icon:'🇦🇷',group:'أمريكا الجنوبية',priority:11},
{id:'usa.1',ar:'الدوري الأمريكي',icon:'🇺🇸',group:'أمريكا الشمالية',priority:12},
{id:'mex.1',ar:'الدوري المكسيكي',icon:'🇲🇽',group:'أمريكا الشمالية',priority:13},
{id:'ksa.1',ar:'الدوري السعودي',icon:'🇸🇦',group:'آسيا',priority:14},
{id:'afc.champions',ar:'دوري أبطال آسيا للنخبة',icon:'🌏',group:'آسيا',priority:15},
{id:'caf.champions',ar:'دوري أبطال أفريقيا',icon:'🌍',group:'أفريقيا',priority:16}
];
const BY=Object.fromEntries(LEAGUES.map(x=>[x.id,x]));
const state={box:null,day:'today',league:'major',status:'all',query:'',matchesByDate:{},busy:false,lastSync:null,error:null,source:'',timer:null};
const esc=v=>{const d=document.createElement('div');d.textContent=String(v??'');return d.innerHTML};
const pad=n=>String(n).padStart(2,'0');
function ammanDate(){const p=new Intl.DateTimeFormat('en-CA',{timeZone:TZ,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date());const o=Object.fromEntries(p.map(x=>[x.type,x.value]));return new Date(`${o.year}-${o.month}-${o.day}T12:00:00`)}
function add(d,n){const x=new Date(d);x.setDate(x.getDate()+n);return x}
function key(d){return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`}
function ymd(d){return `${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}`}
function dates(){const b=ammanDate();return {yesterday:add(b,-1),today:b,tomorrow:add(b,1)}}
function dayName(k){return k==='yesterday'?'أمس':k==='tomorrow'?'غدًا':'اليوم'}
function dayLabel(d){return d.toLocaleDateString('ar-JO',{weekday:'long',day:'numeric',month:'long',year:'numeric',timeZone:TZ})}
function time(v){const d=new Date(v);return isNaN(d)?'—':d.toLocaleTimeString('ar-JO',{hour:'2-digit',minute:'2-digit',hour12:false,timeZone:TZ})}
async function get(url){const c=new AbortController(),t=setTimeout(()=>c.abort(),11000);try{const r=await fetch(url,{cache:'no-store',signal:c.signal,headers:{Accept:'application/json'}});if(!r.ok)throw Error(`HTTP ${r.status}`);return r.json()}finally{clearTimeout(t)}}
function normEvent(e,l){const c=e.competitions?.[0],teams=c?.competitors||[];const h=teams.find(x=>x.homeAway==='home'),a=teams.find(x=>x.homeAway==='away'),s=e.status?.type||{};if(!h||!a)return null;let status='UPCOMING';if(['in','live'].includes(String(s.state).toLowerCase()))status='LIVE';else if(['post','final'].includes(String(s.state).toLowerCase()))status='FINISHED';else if(/postpon/i.test(`${s.name||''} ${s.description||''}`))status='POSTPONED';const hs=h.score!=null?Number(h.score):null,as=a.score!=null?Number(a.score):null;return{id:String(e.id),leagueId:l.id,leagueName:l.ar,leagueIcon:l.icon,group:l.group,priority:l.priority,date:e.date,dateKey:key(new Date(e.date)),home:{name:h.team?.displayName||h.team?.name||'الفريق المضيف',logo:h.team?.logo||h.team?.logos?.[0]?.href||'',score:hs},away:{name:a.team?.displayName||a.team?.name||'الفريق الضيف',logo:a.team?.logo||a.team?.logos?.[0]?.href||'',score:as},status,statusText:s.description||s.detail||'',period:s.period||0,clock:s.displayClock||'',venue:c?.venue?.fullName||c?.venue?.address?.city||'',broadcast:(c?.broadcasts||[]).flatMap(x=>x.names||[]).filter(Boolean),raw:e}}
async function fetchLeague(l,date){const d=await get(`${API}${l.id}/scoreboard?dates=${ymd(date)}`);return(d.events||[]).map(e=>normEvent(e,l)).filter(Boolean)}
function normalizeStatic(x){if(!x)return null;const l=BY[x.leagueId]||{id:x.leagueId,ar:x.leagueName||'بطولة كرة القدم',icon:x.leagueIcon||'⚽',group:'أخرى',priority:99};return{id:String(x.id||x.eventId||''),leagueId:l.id,leagueName:l.ar,leagueIcon:l.icon,group:l.group,priority:l.priority,date:x.date||x.startTime,dateKey:x.dateKey||key(new Date(x.date||x.startTime)),home:{name:x.home?.name||x.homeTeam||x.home||'الفريق المضيف',logo:x.home?.logo||x.homeLogo||'',score:x.home?.score??x.homeScore??null},away:{name:x.away?.name||x.awayTeam||x.away||'الفريق الضيف',logo:x.away?.logo||x.awayLogo||'',score:x.away?.score??x.awayScore??null},status:x.status||'UPCOMING',statusText:x.statusText||'',period:x.period||0,clock:x.clock||'',venue:x.venue||'',broadcast:x.broadcast||[]}}
async function fetchStatic(date){try{const d=await get(`${STATIC}${key(date)}.json`);const a=Array.isArray(d)?d:Array.isArray(d?.matches)?d.matches:[];return a.map(normalizeStatic).filter(x=>x?.id)}catch(_){return[]}}
function merge(arr){const m=new Map();arr.forEach(x=>{if(!x)return;const old=m.get(x.id);m.set(x.id,old?{...old,...x,home:{...old.home,...x.home},away:{...old.away,...x.away}}:x)});return[...m.values()].sort((a,b)=>new Date(a.date)-new Date(b.date)||a.priority-b.priority)}
function activeDates(){const d=dates();return[['yesterday',d.yesterday],['today',d.today],['tomorrow',d.tomorrow]]}
function allMatches(){return Object.values(state.matchesByDate).flat()}
function matchesFor(dateKey){let a=state.matchesByDate[dateKey]||[];if(state.league!=='major'&&state.league!=='all')a=a.filter(x=>x.leagueId===state.league);else if(state.league==='major')a=a.filter(x=>x.priority<=16);if(state.status!=='all')a=a.filter(x=>x.status===state.status);if(state.query){const q=state.query.trim().toLowerCase();a=a.filter(x=>[x.home.name,x.away.name,x.leagueName].some(v=>String(v).toLowerCase().includes(q)))}return a}
function logo(t){return `<div class="zmc-logo">${t.logo?`<img src="${esc(t.logo)}" alt="" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'">`:''}<span ${t.logo?'style="display:none"':''}>⚽</span></div>`}
function statusText(x){if(x.status==='LIVE')return'مباشر الآن';if(x.status==='FINISHED')return'انتهت';if(x.status==='POSTPONED')return'مؤجلة';return'موعد المباراة'}
function score(x){return x.home.score!=null&&x.away.score!=null?`<span dir="ltr"><b>${Number(x.home.score)}</b><i>:</i><b>${Number(x.away.score)}</b></span>`:`<span class="zmc-time">${esc(time(x.date))}</span>`}
function outcome(x){
  const hs=x.home.score,as=x.away.score;
  if(x.status!=='FINISHED'||hs==null||as==null)return '';
  const h=Number(hs),a=Number(as);
  if(h===a)return `<div class="zmc-outcome draw">تعادل ${h} - ${a}</div>`;
  const winner=h>a?x.home:x.away, loser=h>a?x.away:x.home, ws=Math.max(h,a),ls=Math.min(h,a);
  return `<div class="zmc-outcome"><strong>فاز ${esc(winner.name)}</strong> ${ws} - ${ls} <span>على ${esc(loser.name)}</span></div>`;
}
function matchCard(x){const live=x.status==='LIVE';return `<article class="zmc-match ${live?'is-live':''}"><button class="zmc-open" data-open-match="${esc(x.id)}"><div class="zmc-match-head"><span>${live?'🔴 مباشر الآن':esc(statusText(x))}</span><small>${esc(time(x.date))}</small></div><div class="zmc-teams"><div class="zmc-team">${logo(x.home)}<strong translate="no">${esc(x.home.name)}</strong></div><div class="zmc-score">${score(x)}<small>${live?esc(x.clock||'مباشر'):x.status==='FINISHED'?'النتيجة النهائية':'ركلة البداية'}</small>${outcome(x)}</div><div class="zmc-team">${logo(x.away)}<strong translate="no">${esc(x.away.name)}</strong></div></div><div class="zmc-match-foot">${x.venue?`<span>📍 ${esc(x.venue)}</span>`:''}<em>تفاصيل المباراة ←</em></div></button></article>`}
function dayPanel(k,d,leagueId){const items=(state.matchesByDate[key(d)]||[]).filter(x=>x.leagueId===leagueId);const filtered=items.filter(x=>state.status==='all'||x.status===state.status).filter(x=>!state.query||[x.home.name,x.away.name,x.leagueName].some(v=>String(v).toLowerCase().includes(state.query.toLowerCase())));return `<div class="zmc-day-panel ${k==='today'?'current':''}"><header><div><span>${dayName(k)}</span><strong>${esc(dayLabel(d))}</strong></div><b>${filtered.length} مباراة</b></header>${filtered.length?`<div class="zmc-match-list">${filtered.map(matchCard).join('')}</div>`:`<div class="zmc-day-empty">لا توجد مباريات متاحة لهذا الدوري في ${dayName(k)}.</div>`}</div>`}
function competitionSection(l,d){return `<section class="zmc-competition"><header class="zmc-comp-head"><div class="zmc-comp-title"><span class="zmc-comp-icon">${esc(l.icon)}</span><div><h3>${esc(l.ar)}</h3><small>${esc(l.group)} · مباريات الأمس واليوم والغد</small></div></div><span class="zmc-comp-count">${[d.yesterday,d.today,d.tomorrow].reduce((n,x)=>n+(state.matchesByDate[key(x)]||[]).filter(m=>m.leagueId===l.id).length,0)} مباراة</span></header><div class="zmc-days">${dayPanel('yesterday',d.yesterday,l.id)}${dayPanel('today',d.today,l.id)}${dayPanel('tomorrow',d.tomorrow,l.id)}</div></section>`}
function catalog(){const map=new Map(LEAGUES.map(x=>[x.id,x]));allMatches().forEach(x=>{if(!map.has(x.leagueId))map.set(x.leagueId,{id:x.leagueId,ar:x.leagueName||'بطولة كرة القدم',icon:x.leagueIcon||'⚽',group:x.group||'بطولات أخرى',priority:Number(x.priority)||99})});return [...map.values()].sort((a,b)=>a.priority-b.priority||a.ar.localeCompare(b.ar,'ar'))}
function render(){if(!state.box)return;const d=dates();const catalogList=catalog();const pool=state.league==='major'?LEAGUES:state.league==='all'?catalogList:[BY[state.league]].filter(Boolean);const total=allMatches().length,live=allMatches().filter(x=>x.status==='LIVE').length,finished=allMatches().filter(x=>x.status==='FINISHED').length,upcoming=allMatches().filter(x=>x.status==='UPCOMING').length;const visible=pool.filter(l=>activeDates().some(([_,dt])=>matchesFor(key(dt)).some(x=>x.leagueId===l.id)));const sections=visible.map(l=>competitionSection(l,d)).join('');state.box.innerHTML=`<div class="zmc-shell"><div class="zmc-hero"><div><span class="zmc-eyebrow">⚽ مركز كرة القدم العالمي</span><h2>مركز المباريات</h2><p>كل بطولة في قسم مستقل، ومباريات الأمس واليوم والغد في مكان واحد.</p></div><div class="zmc-live-counter"><b>${live}</b><span>مباشر الآن</span></div></div><div class="zmc-day-nav"><button data-focus-day="yesterday" class="${state.day==='yesterday'?'active':''}">أمس</button><button data-focus-day="today" class="${state.day==='today'?'active':''}">اليوم</button><button data-focus-day="tomorrow" class="${state.day==='tomorrow'?'active':''}">غدًا</button></div><div class="zmc-tools"><select id="zmc-league"><option value="major">⭐ البطولات الكبرى</option><option value="all">🌍 كل البطولات المتاحة</option>${catalogList.map(l=>`<option value="${esc(l.id)}" ${state.league===l.id?'selected':''}>${esc(l.ar)}</option>`).join('')}</select><select id="zmc-status"><option value="all">كل الحالات</option><option value="LIVE" ${state.status==='LIVE'?'selected':''}>🔴 مباشر</option><option value="UPCOMING" ${state.status==='UPCOMING'?'selected':''}>قادمة</option><option value="FINISHED" ${state.status==='FINISHED'?'selected':''}>انتهت</option></select><input id="zmc-search" value="${esc(state.query)}" placeholder="ابحث عن فريق أو بطولة"><button id="zmc-refresh">🔄 تحديث</button></div><div class="zmc-kpis"><div><b>${total}</b><span>مباراة محملة</span></div><div class="live"><b>${live}</b><span>مباشر</span></div><div><b>${finished}</b><span>انتهت</span></div><div><b>${upcoming}</b><span>قادمة</span></div></div>${state.error?`<div class="zmc-notice">${esc(state.error)}</div>`:''}<main class="zmc-content">${sections||`<div class="zmc-empty"><span>⚽</span><strong>لا توجد مباريات متاحة في الاختيار الحالي</strong><small>جرّب بطولة أخرى أو يومًا آخر.</small></div>`}</main><footer class="zmc-footer"><span>ربط مباشر ببيانات المباريات · ${esc(state.source||'—')}</span><span>${state.lastSync?`آخر تحديث ${esc(time(state.lastSync))}`:'—'}</span></footer></div>`;bind()}
function bind(){const b=state.box;b.querySelectorAll('[data-focus-day]').forEach(x=>x.onclick=()=>{state.day=x.dataset.focusDay;document.querySelector(`[data-day-anchor="${x.dataset.focusDay}"]`)?.scrollIntoView({behavior:'smooth',block:'start'});render()});b.querySelector('#zmc-league').onchange=e=>{state.league=e.target.value;render()};b.querySelector('#zmc-status').onchange=e=>{state.status=e.target.value;render()};b.querySelector('#zmc-search').oninput=e=>{state.query=e.target.value;render()};b.querySelector('#zmc-refresh').onclick=()=>load();b.querySelectorAll('[data-open-match]').forEach(x=>x.onclick=e=>{e.preventDefault();openDetails(x.dataset.openMatch)})}
async function load(){
  if(!state.box||state.busy)return;
  state.busy=true; state.error=null; render();
  const ds=activeDates(); const all=[]; let directOk=0, directFailed=0, staticOk=0;
  try{
    // Static GitHub snapshot is the free-plan reliability layer; direct ESPN is enrichment.
    for(const [_,d] of ds){ const rows=await fetchStatic(d); if(rows.length) staticOk++; all.push(...rows); }
    // Refresh major competitions from ESPN. Keep the UI alive even if one provider fails.
    for(let i=0;i<LEAGUES.length;i+=4){
      const chunk=LEAGUES.slice(i,i+4);
      const r=await Promise.allSettled(chunk.flatMap(l=>ds.map(([_,d])=>fetchLeague(l,d))));
      r.forEach(x=>{if(x.status==='fulfilled'){directOk++;all.push(...x.value)}else directFailed++});
    }
    const merged=merge(all);
    state.matchesByDate={}; merged.forEach(x=>(state.matchesByDate[x.dateKey]??=[]).push(x));
    state.lastSync=new Date();
    state.source=directOk?'ESPN مباشر + لقطة الموقع':staticOk?'لقطة الموقع الموثوقة':'—';
    if(!merged.length) state.error='لا توجد بيانات مباريات متاحة حاليًا. سيعاد المحاولة تلقائيًا.';
    else if(directFailed && staticOk) state.error='تم عرض آخر بيانات محفوظة مع تحديث مباشر متاح جزئيًا.';
  }catch(e){
    state.error='تعذر تحديث مصدر المباريات؛ تم الحفاظ على البيانات المتاحة إن وجدت.';
  }finally{ state.busy=false; render(); schedule(); }
}
async function openDetails(id){const x=allMatches().find(m=>m.id===id);if(!x)return;document.getElementById('zmc-modal')?.remove();const modal=document.createElement('div');modal.id='zmc-modal';modal.className='zmc-modal';modal.innerHTML=`<div class="zmc-dialog"><button class="zmc-close">×</button><div class="zmc-detail-league">${esc(x.leagueIcon)} ${esc(x.leagueName)} · ${esc(statusText(x))}</div><div class="zmc-detail-score"><div>${logo(x.home)}<strong translate="no">${esc(x.home.name)}</strong></div><section>${score(x)}<small>${esc(x.clock||time(x.date))}</small>${outcome(x)}</section><div>${logo(x.away)}<strong translate="no">${esc(x.away.name)}</strong></div></div><div class="zmc-detail-meta">${x.venue?`<span>📍 ${esc(x.venue)}</span>`:''}${x.broadcast?.length?`<span>📺 ${esc(x.broadcast.join('، '))}</span>`:''}</div><div class="zmc-events"><h3>أحداث المباراة</h3><p>جاري تحميل التفاصيل...</p></div></div>`;document.body.appendChild(modal);modal.querySelector('.zmc-close').onclick=()=>modal.remove();modal.onclick=e=>{if(e.target===modal)modal.remove()};try{const d=await get(`${API}${x.leagueId}/summary?event=${encodeURIComponent(x.id)}`);const plays=d.plays||d.keyEvents||[];const events=plays.map(p=>{const minute=p.clock?.displayValue||p.time?.displayValue||'';const text=p.text||p.shortText||p.type?.text||p.type?.description||'';return minute||text?`<div><b>${esc(minute)}</b><span>${esc(text)}</span></div>`:''}).filter(Boolean).slice(-80).reverse();modal.querySelector('.zmc-events').innerHTML=`<h3>أحداث المباراة</h3>${events.length?events.join(''):'<p>لا توجد أحداث تفصيلية متاحة حاليًا.</p>'}`}catch(_){modal.querySelector('.zmc-events').innerHTML='<h3>أحداث المباراة</h3><p>تعذر تحميل التفاصيل المباشرة حاليًا.</p>'}}
function schedule(){clearTimeout(state.timer);state.timer=setTimeout(()=>load(),state.matchesByDate&&Object.values(state.matchesByDate).flat().some(x=>x.status==='LIVE')?30000:120000)}
function mount(box){state.box=box;load()}
window.ZIVOZONE_FIXTURES={load:mount};window.ZIVOZONE_MATCH_CENTER={load:mount,refresh:load};window.ZIVOZONE=window.ZIVOZONE||{};window.ZIVOZONE.Sports={getMatches:allMatches};
})();
