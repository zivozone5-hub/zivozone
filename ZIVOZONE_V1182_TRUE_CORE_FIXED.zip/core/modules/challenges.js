/* ZIVOZONE V1180 — CANONICAL CHALLENGE ENGINE
   One owner for all challenges and Dark Room.
   The old challenge runners are removed from runtime; this module owns
   selection, session state, scoring, Dark Room cinema, progress and rewards.
*/
(()=>{
'use strict';
const C=()=>window.ZIVOZONE_CHALLENGES||{};
const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const text=v=>{if(typeof v==='string')return v;if(v&&typeof v==='object')return v[document.documentElement.lang]||v.ar||v.en||Object.values(v)[0]||'';return String(v??'')};
const norm=v=>text(v).trim().toLowerCase().replace(/[أإآ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').replace(/[،,؛;]/g,' ').replace(/\s+/g,' ');
const STORE='zivozone.challenge.core.v1125';
const read=(k,f)=>{try{return JSON.parse(localStorage.getItem(k)||JSON.stringify(f))}catch(_){return f}};
const write=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(_){}};
const banks=()=>{const all=[...Object.values(C()),...Object.values(window.ZIVOZONE_V18_BANK||{}),...Object.values(window.ZIVOZONE_V40_BANK||{})];const seen=new Set();return all.filter(b=>b&&b.id&&Array.isArray(b.questions)&&!seen.has(b.id)&&seen.add(b.id))};
const bank=id=>banks().find(b=>String(b.id)===String(id))||null;
const difficulty=q=>Math.max(1,Math.min(10,Number(q?.difficulty??q?.d??1)||1));
const player=()=>window.ZIVOZONE?.Player?.get?.()||window.ZIVOZONE_PLAYER?.get?.()||{};
const audio=()=>window.ZIVOZONE_AUDIO||{};
const user=()=>window.firebase?.auth?.()?.currentUser||window.ZIVOZONE?.Auth?.user||null;

function usedMap(){return read(STORE+':used',{})}
function chooseQuestions(b,count){
  const h=usedMap(), used=new Set(Array.isArray(h[b.id])?h[b.id]:[]);
  let pool=b.questions.filter(q=>q?.id&&!used.has(q.id));
  if(pool.length<count)pool=b.questions.slice();
  const p=player(), level=Math.max(1,Number(p.level)||1), hist=Array.isArray(p.history)?p.history.slice(-8):[];
  const avg=hist.length?hist.reduce((n,x)=>n+(Number(x.score)||0),0)/hist.length:50;
  const adaptive=read(STORE+':adaptive',{}), a=adaptive[b.id]||{};
  let shift=level>=20?1:level>=8?.5:0;if(avg>=80)shift+=.5;if(avg<45)shift-=.5;shift+=Math.min(2.5,(Number(a.perfectRuns)||0)*.7);
  const target=Array.from({length:count},(_,i)=>Math.max(1,Math.min(10,Math.round((i/(count-1||1))*9+1+shift*(i/(count-1||1))))));
  const left=pool.slice(),run=[];
  for(const t of target){if(!left.length)break;let bi=0,best=Infinity;left.forEach((q,i)=>{const d=Math.abs(difficulty(q)-t)+Math.random()*.3;if(d<best){best=d;bi=i}});run.push(left.splice(bi,1)[0]);}
  while(run.length<count&&left.length)run.push(left.shift());
  const next=usedMap(), arr=Array.isArray(next[b.id])?next[b.id]:[];next[b.id]=Array.from(new Set([...arr,...run.map(q=>q.id)])).slice(-Math.max(300,b.questions.length));write(STORE+':used',next);
  return run.slice(0,count);
}
function markAdaptive(id,score,total,timed){const a=read(STORE+':adaptive',{}),x=a[id]||{};const perfect=score===total&&timed===0;a[id]={attempts:(x.attempts||0)+1,perfectRuns:(x.perfectRuns||0)+(perfect?1:0),lastScore:score,lastAt:Date.now()};write(STORE+':adaptive',a)}

const cinema={
  active:false, phase:1, question:1, answered:0, introTimer:null, mode:'forensic',
  mount(){
    let e=document.getElementById('zivo-cinematic-entry');
    if(e)return e;
    e=document.createElement('div'); e.id='zivo-cinematic-entry'; e.className='zivo-cinematic-entry'; e.dir='rtl';
    e.innerHTML=`<div class="zce-grid"></div><div class="zce-noise"></div><div class="zce-light"></div><div class="zce-scan"></div><div class="zce-corners"><i></i><i></i><i></i><i></i></div>
      <div class="zce-top"><span>ZIVOZONE // ${this.mode==='horror'?'وحدة الظلام':'وحدة التحقيق'}</span><span id="zce-file">ملف ${this.mode==='horror'?'DARK-001':'CASE-001'}</span></div>
      <main class="zce-main"><div class="zce-seal" id="zce-seal">إشارة محفوظة</div><div class="zce-kicker" id="zce-kicker">المختبر الجنائي</div>
      <h1 id="zce-title">القضية تبدأ الآن</h1><p class="zce-line" id="zce-line">أغلق الضوضاء. افتح الأدلة.</p>
      <div class="zce-loader"><b></b></div><div class="zce-status" id="zce-status">تهيئة النظام</div></main>
      <footer class="zce-bottom"><span id="zce-bottom-a">كل قرار يغيّر مسار التجربة</span><span>الدخول الآمن • ZIVOZONE</span></footer>`;
    document.body.appendChild(e); return e;
  },
  intro(done,mode='forensic'){
    this.mode=mode; this.active=true; this.phase=1; this.question=1; this.answered=0;
    const e=this.mount();
    document.body.classList.add('zivo-cinematic-active');
    if(mode==='horror')document.body.classList.add('zivo-dark-cinematic');
    else document.body.classList.remove('zivo-dark-cinematic');
    e.classList.add('show');
    const line=e.querySelector('#zce-line'), status=e.querySelector('#zce-status');
    e.querySelector('#zce-kicker').textContent=mode==='horror'?'الغرفة المظلمة':'المختبر الجنائي';
    e.querySelector('#zce-title').textContent=mode==='horror'?'الدخول إلى الظلام':'القضية تبدأ الآن';
    e.querySelector('#zce-seal').textContent=mode==='horror'?'إشارة غير معروفة':'دليل محفوظ';
    e.querySelector('#zce-file').textContent=mode==='horror'?'ملف DARK-001':'ملف CASE-001';
    e.querySelector('#zce-bottom-a').textContent=mode==='horror'?'لا تدخل إن لم تكن مستعدًا للخروج':'كل قرار يغيّر مسار التحقيق';
    const steps=mode==='horror'
      ?[['تهيئة الإشارة','الغرفة تستجيب لوجودك…'],['فتح المسار','الصوت يتغير. لا تعتمد على ما تراه.'],['تصعيد الإيقاع','كل مرحلة ستصبح أكثر ضغطًا.'],['الغرفة جاهزة','أنت داخل التجربة الآن.']]
      :[['تهيئة مسرح القضية','افحص المشهد قبل أن تلمس أي دليل.'],['فتح سجل الأدلة','كل تفصيل له سياق… لا تتسرع في الاستنتاج.'],['تحليل التسلسل الزمني','ابحث عن الشيء الذي لا ينسجم مع الرواية.'],['القضية جاهزة','أنت المحقق الآن. ابدأ الفحص.']];
    let i=0;
    const run=()=>{
      if(!this.active)return;
      if(i>=steps.length){
        e.classList.add('exit');
        setTimeout(()=>{e.classList.remove('show','exit');document.body.classList.remove('zivo-cinematic-active','zivo-dark-cinematic');done()},700);
        return;
      }
      status.textContent=steps[i][0]; line.textContent=steps[i][1]; e.dataset.step=String(i+1); i++;
      this.introTimer=setTimeout(run,i===steps.length?1500:1200);
    };
    run();
  },
  start(mode='forensic'){this.mode=mode;this.active=true},
  stop(){this.active=false;clearTimeout(this.introTimer);const e=document.getElementById('zivo-cinematic-entry');e?.remove();document.body.classList.remove('zivo-cinematic-active','zivo-dark-cinematic')},
  step(){if(this.active)this.phase=Math.min(3,this.phase+1)}
};

const exitGuard={
  open(onConfirm){
    if(document.getElementById('zivo-exit-confirm'))return;
    const m=document.createElement('div');m.id='zivo-exit-confirm';m.className='zivo-exit-confirm';m.dir='rtl';
    m.innerHTML=`<div class="zivo-exit-card"><span class="zivo-exit-kicker">ZIVOZONE // تأكيد الخروج</span><h2>هل أنت متأكد من الخروج؟</h2><p>سيتم إنهاء التحدي والعودة مباشرة إلى الموقع.</p><div><button type="button" class="zivo-exit-stay">البقاء</button><button type="button" class="zivo-exit-confirm-btn">نعم، اخرج للموقع</button></div></div>`;
    document.body.appendChild(m);
    const close=()=>m.remove();
    m.querySelector('.zivo-exit-stay').onclick=close;
    m.querySelector('.zivo-exit-confirm-btn').onclick=()=>{close();onConfirm?.()};
    m.onclick=e=>{if(e.target===m)close()};
  }
};


const runner={mount:null,run:null,index:0,correct:0,score:0,streak:0,best:0,timed:0,timer:null,locked:false,startedAt:0,guest:true,checkpoint:false,
 ensure(){if(this.mount)return this.mount;const m=document.createElement('div');m.id='zivo-challenge-core';m.className='zivo-challenge-core';document.body.appendChild(m);this.mount=m;return m},
 start(id){if(id==='horror')document.body.classList.add('zivo-darkroom-active');else document.body.classList.remove('zivo-darkroom-active');if(id==='forensic'&&window.ZIVOZONE_FORENSIC_CORE?.start){this.guest=!user();return window.ZIVOZONE_FORENSIC_CORE.start()}const b=bank(id);if(!b||!b.questions?.length)return false;this.guest=!user();const isDark=id==='horror';const isForensic=id==='forensic';const count=isDark?30:10;this.run={id,title:text(b.title||b.name||'التحدي'),icon:b.icon||'🎯',questions:chooseQuestions(b,count),xp:Number(b.xp)||80};if(isDark){cinema.start('horror');cinema.intro(()=>{this.reset();this.render()},'horror')}
else if(isForensic){cinema.start('forensic');cinema.intro(()=>{this.reset();this.render()},'forensic')}
else{this.reset();this.render()}return true},
 reset(){clearInterval(this.timer);this.index=0;this.correct=0;this.score=0;this.streak=0;this.best=0;this.timed=0;this.locked=false;this.startedAt=Date.now();const m=this.ensure();m.classList.add('active');document.body.classList.add('zivo-challenge-active');m.dataset.mode=this.run.id==='horror'?'dark':'standard'},
 render(){const q=this.run.questions[this.index];if(!q){this.finish();return}this.locked=false;clearInterval(this.timer);const m=this.ensure(),darkMode=this.run.id==='horror',d=difficulty(q),phase=d>=8?'EXTREME':d>=6?'HARD':d>=4?'MEDIUM':'EASY',choices=q.a||q.options||q.choices||q.answers;const area=Array.isArray(choices)&&choices.length?`<div class="zcr-options">${choices.map((x,i)=>`<button class="zcr-option" type="button" data-i="${i}"><span>${String.fromCharCode(65+i)}</span><b>${esc(text(x))}</b></button>`).join('')}</div>`:`<form class="zcr-form"><input autocomplete="off" aria-label="الإجابة" placeholder="اكتب إجابتك"><button type="submit">إجابة</button></form>`;m.innerHTML=`<div class="zcr-shell ${darkMode?'zcr-dark':''}" dir="rtl"><header class="zcr-head"><div><small>${darkMode?'DARK ROOM // ZIVOZONE':'ZIVOZONE CHALLENGE'}</small><h2>${esc(this.run.icon)} ${esc(this.run.title)}</h2></div><div class="zcr-progress-meta"><b>${this.index+1}/${this.run.questions.length}</b><strong id="zcr-time">30</strong></div></header><div class="zcr-progress"><i style="width:${(this.index/this.run.questions.length)*100}%"></i></div><main class="zcr-main"><div class="zcr-context"><span>${phase}</span><span>${darkMode?`PHASE 0${cinema.phase}`:'LIVE'}</span><span>🔥 ${this.streak}</span></div><article class="zcr-question">${q?.extra?.image?`<div class="zcr-evidence"><img src="${esc(q.extra.image)}" alt="دليل القضية" loading="eager"></div>`:''}<div class="zcr-number">QUESTION ${String(this.index+1).padStart(2,'0')}</div><h1>${esc(text(q.q||q.question||''))}</h1>${area}<div class="zcr-feedback" aria-live="polite"></div></article></main><footer class="zcr-foot"><span>${darkMode?'لا توجد إجابة تكشف لك الحقيقة. استمر.':`النقاط ${this.score} · الصحيحة ${this.correct}`}</span><button type="button" class="zcr-exit">خروج</button></footer></div>`;m.querySelector('.zcr-exit').onclick=()=>this.requestClose();m.querySelectorAll('.zcr-option').forEach(b=>b.onclick=()=>this.submit(b,q));const f=m.querySelector('.zcr-form');if(f)f.onsubmit=e=>{e.preventDefault();this.submit(f,q)};let left=30;this.timer=setInterval(()=>{left--;const t=m.querySelector('#zcr-time');if(t)t.textContent=left;try{audio().tick?.()}catch(_){}if(left<=0){clearInterval(this.timer);if(this.locked)return;this.locked=true;this.timed++;try{audio().timeout?.()}catch(_){}if(darkMode)cinema.step();setTimeout(()=>{this.index++;if(darkMode&&this.index%10===0){this.checkpoint=true;this.renderCheckpoint()}else this.render()},420)}},1000)},
 answer(q,value){const v=norm(value),choices=q.a||q.options||q.choices||q.answers;if(Array.isArray(choices)&&Number.isInteger(Number(q.c))){const i=Number(q.c);if(i>=0&&i<choices.length&&norm(choices[i])===v)return true}const direct=q.answer??q.extra?.answer;if(direct!==undefined&&norm(direct)===v)return true;return Array.isArray(q.alternatives)&&q.alternatives.some(x=>norm(x)===v)},
 submit(el,q){if(this.locked)return;this.locked=true;clearInterval(this.timer);const value=el?.dataset?.i!==undefined?(q.a||q.options||q.choices||q.answers)[Number(el.dataset.i)]:el?.querySelector?.('input')?.value;const ok=this.answer(q,value);if(ok){this.correct++;this.streak++;this.best=Math.max(this.best,this.streak);this.score+=Math.max(10,55+difficulty(q)*5)}else this.streak=0;try{audio()[ok?'correct':'wrong']?.()}catch(_){}const f=this.mount.querySelector('.zcr-feedback');if(f)f.textContent=ok?'✓ تم تسجيل الإجابة':'✕ تم تسجيل الإجابة';if(this.run.id==='horror')cinema.step();setTimeout(()=>{this.index++;if(this.run.id==='horror'&&this.index%10===0&&this.index<this.run.questions.length){this.renderCheckpoint()}else this.render()},520)},
 renderCheckpoint(){clearInterval(this.timer);const darkMode=true;this.mount.innerHTML=`<div class="zcr-checkpoint" dir="rtl"><span class="zcr-cp-kicker">DARK ROOM // THRESHOLD</span><h2>لقد عبرت ${this.index} أسئلة.</h2><p>الإيقاع التالي مختلف. لا يوجد زر بداية هنا؛ أنت بالفعل داخل الغرفة.</p><div class="zcr-cp-actions"><button type="button" class="zcr-continue">أكمل</button><button type="button" class="zcr-exit">أخرج الآن</button></div></div>`;this.mount.querySelector('.zcr-continue').onclick=()=>this.render();this.mount.querySelector('.zcr-exit').onclick=()=>this.requestClose();cinema.whisper(this.index>=20?'المرحلة الأخيرة بدأت.':'الغرفة ترفع مستوى الإشارة.',true)},
 async finish(){clearInterval(this.timer);const total=this.run.questions.length,perfect=this.correct===total&&this.timed===0;markAdaptive(this.run.id,this.correct,total,this.timed);try{await window.ZIVOZONE?.Player?.addProgress?.({id:this.run.id,score:this.correct,bestStreak:this.best,timedOut:this.timed,questions:total,speedScore:Math.max(0,100-this.timed*8)})}catch(_){}const reward=perfect?10:0;const rewardEventId=crypto?.randomUUID?.()||`challenge_${Date.now()}`;try{if(perfect)await window.ZIVOZONE?.Economy?.rewardChallenge?.({challengeId:this.run.id,amount:reward,eventId:rewardEventId})}catch(_){}window.dispatchEvent(new CustomEvent('zivozone-result',{detail:{challenge:this.run.id,gameId:this.run.id,score:this.correct,total,correct:this.correct,perfect,timedOut:this.timed,xp:0,coins:reward,zivoReward:reward,eventId:rewardEventId}}));this.mount.innerHTML=`<div class="zcr-result" dir="rtl"><span class="zcr-result-kicker">ZIVOZONE // RESULT</span><div class="zcr-result-score">${this.correct}<small>/${total}</small></div><h2>${perfect?'جولة مثالية':'انتهت الجولة'}</h2><p>أفضل سلسلة: <b>${this.best}</b> · انتهى الوقت: <b>${this.timed}</b></p><p>${perfect?'🏆 +10 ZIVO':'🧠 الجولة القادمة ستتكيّف مع مستواك'}</p><div><button class="zcr-again">جولة جديدة</button><button class="zcr-exit">خروج</button></div></div>`;this.mount.querySelector('.zcr-again').onclick=()=>this.start(this.run.id);this.mount.querySelector('.zcr-exit').onclick=()=>this.requestClose();if(this.run.id==='horror')cinema.stop(); if(this.run.id==='forensic')cinema.stop()},
 requestClose(){if(!this.run)return;exitGuard.open(()=>this.close())},
 close(){clearInterval(this.timer);this.timer=null;this.mount?.classList.remove('active');document.body.classList.remove('zivo-challenge-active','zivo-darkroom-active','zivo-dark-cinematic');if(cinema.active)cinema.stop();this.run=null;location.hash='#home';window.scrollTo?.({top:0,behavior:'instant'})}
};
const CATEGORY_ACCENT={football:'#2f6bff',football_intelligence:'#2f6bff',iq:'#b34cff',logic:'#b34cff',logic_extreme:'#b34cff',memory:'#b34cff',memory_focus:'#b34cff',science:'#b34cff',math:'#b34cff',strategy:'#22c55e',daily:'#ffb020'};
const accentFor=id=>CATEGORY_ACCENT[id]||'#2f6bff';
const levelFor=b=>{const qs=Array.isArray(b.questions)?b.questions:[];if(!qs.length)return 1;const avg=qs.reduce((n,q)=>n+difficulty(q),0)/qs.length;return Math.max(1,Math.min(5,Math.round(avg/2)))};
function renderCenter(){
  const host=document.getElementById('challenge-list'); if(!host)return false;
  const all=banks(); const today=new Date().toISOString().slice(0,10); const done=localStorage.getItem('zivo_daily_'+today);
  const posterMap={
    iq:'assets/challenge-posters/iq.svg',science:'assets/challenge-posters/science.svg',daily:'assets/challenge-posters/daily.svg',football:'assets/challenge-posters/football.svg',
    logic:'assets/challenge-posters/logic.svg',memory:'assets/challenge-posters/memory.svg',strategy:'assets/challenge-posters/strategy.svg',math:'assets/challenge-posters/math.svg',
    forensic:'assets/forensic-cinema/entry.svg',horror:'assets/challenge-posters/horror.svg',code_v22:'assets/challenge-posters/code.svg',visual_v22:'assets/challenge-posters/visual.svg',
    probability_v22:'assets/challenge-posters/probability.svg',football_intelligence:'assets/challenge-posters/football.svg',logic_v18:'assets/challenge-posters/logic.svg',pattern_v18:'assets/challenge-posters/visual.svg',
    focus_v18:'assets/challenge-posters/focus.svg',logic_extreme:'assets/challenge-posters/logic.svg',memory_focus:'assets/challenge-posters/memory.svg'
  };
  const seen=new Set(); const list=all.filter(x=>x&&!['horror','forensic'].includes(x.id)&&!seen.has(x.id)&&seen.add(x.id));
  const locTitle=x=>text(x.title||x.name||x.id), locDesc=x=>text(x.desc||'تحدٍ تفاعلي مصمم داخل ZIVOZONE.');
  host.innerHTML=list.map(x=>{
    const dark=x.id==='horror', forensic=x.id==='forensic', dailyDone=done&&x.id==='daily';
    const img=posterMap[x.id]||'assets/challenge-posters/visual.svg'; const total=Array.isArray(x.questions)?x.questions.length:0;
    const cls=`challenge-card ${dark?'challenge-card-dark':''} ${forensic?'challenge-card-forensic':''} ${dailyDone?'challenge-card-done':''}`;
    const accent=accentFor(x.id), level=levelFor(x), icon=x.icon||'🎯';
    const metaRow=(dark||forensic)
      ? `<div class="challenge-badges"><span class="card-tag ${dark?'danger':''}">${dark?'DARK ROOM':'المختبر الجنائي'}</span><span class="challenge-count">${total} سؤال</span></div>`
      : `<div class="challenge-meta-row"><span class="challenge-icon-badge" style="--badge-accent:${accent}">${icon}</span><span class="level-badge">المستوى ${level}</span></div>`;
    return `<article class="${cls}" data-challenge="${esc(x.id)}" tabindex="0" role="button" aria-label="${esc(locTitle(x))}" style="--card-accent:${accent}">
      <div class="challenge-visual"><img src="${img}" alt="" loading="lazy"><span class="challenge-visual-glow"></span>${dark?'<span class="challenge-cinematic-badge">FULL SCREEN</span>':''}${forensic?'<span class="challenge-cinematic-badge forensic">CASE LAB</span>':''}</div>
      <div class="challenge-copy">${dark||forensic?metaRow:''}
      <h3>${esc(locTitle(x))}</h3><p>${esc(locDesc(x))}</p>${dark||forensic?'':metaRow}<div class="challenge-enter-line"><span>${dailyDone?'مكتمل اليوم':'اضغط في أي مكان للدخول'}</span><b>↗</b></div></div>
    </article>`;
  }).join('');
  const lvl=document.getElementById('player-level-chip'); if(lvl){const p=player();lvl.textContent=`Level ${Number(p.level)||1}`}
  return true;
}
window.ZIVOZONE_START_CHALLENGE=id=>runner.start(id);
window.ZIVOZONE_DARKROOM={start:()=>runner.start('horror'),stop:()=>cinema.stop(),isActive:()=>cinema.active};
window.ZIVOZONE_CHALLENGE_CORE=Object.freeze({version:'1182',get:bank,getAll:banks,start:id=>runner.start(id),darkRoom:()=>runner.start('horror'),stats:()=>banks().map(b=>({id:b.id,title:text(b.title||b.name),total:b.questions.length})),clearHistory:()=>{write(STORE+':used',{});write(STORE+':adaptive',{})},renderCenter});
window.ZIVOZONE=window.ZIVOZONE||{};window.ZIVOZONE.Challenges=window.ZIVOZONE_CHALLENGE_CORE;

document.addEventListener('click',e=>{const card=e.target.closest('[data-challenge]');if(card){e.preventDefault();runner.start(card.dataset.challenge)}});
document.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.closest('[data-challenge]')){e.preventDefault();runner.start(e.target.closest('[data-challenge]').dataset.challenge)}});
document.addEventListener('keydown',e=>{
  if(e.key==='Escape' && runner.run){e.preventDefault();runner.requestClose()}
});


})();
