/* ZIVOZONE V1180 — PLAYER HOME CORE
   Canonical owner of the player's home/journey.
   One domain: identity -> progression -> economy -> activity -> destinations.
   No legacy hub layers, no duplicate player stores, no fake progress.
*/
(()=>{
'use strict';
const VERSION='1180';
const $=s=>document.querySelector(s);
const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const user=()=>{try{return window.firebase?.auth?.()?.currentUser||window.ZIVOZONE?.Auth?.()?.user||null}catch(_){return null}};
const player=()=>window.ZIVOZONE?.Player?.get?.()||{};
const wallet=()=>window.ZIVOZONE?.Economy?.getWallet?.()||{};
const missions=()=>window.ZIVOZONE?.Missions?.get?.()||{items:{},claimed:{}};
const competition=()=>window.ZIVOZONE?.Competition?.state?.()||{streak:0,completed:false,claimed:false,days:[]};
const achievements=()=>window.ZIVOZONE?.Achievements?.state?.()||{unlocked:[]};
const sports=()=>window.ZIVOZONE?.Sports?.getMatches?.()||[];
const events=()=>window.ZIVOZONE?.Events?.getHistory?.()||[];
const fmt=n=>{n=Number(n)||0;return Number.isInteger(n)?String(n):n.toFixed(2).replace(/0+$/,'').replace(/\.$/,'')};
const today=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Amman',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
const cloud=()=>!!user()&&!!window.firebase?.firestore;
const levelFor=x=>Math.max(1,Math.floor(Math.sqrt(Math.max(0,Number(x)||0)/100))+1);
const levelInfo=(xp,lvl)=>{lvl=Number(lvl)||levelFor(xp);const base=Math.pow(lvl-1,2)*100,next=Math.pow(lvl,2)*100;return{base,next,pct:Math.max(0,Math.min(100,((xp-base)/(next-base))*100))}};
let root=null, timer=null, unsubs=[];

function close(){root?.classList.remove('open');document.body.classList.remove('zivo-player-home-open');clearInterval(timer);unsubs.forEach(f=>f&&f());unsubs=[]}
function go(id){close();const fn={challenges:()=>$('#challenges')?.scrollIntoView({behavior:'smooth'}),sports:()=>$('#sports')?.scrollIntoView({behavior:'smooth'}),profile:()=>open(),identity:()=>$('[data-action="open-identity"]')?.click(),ai:()=>location.hash='#ai',wallet:()=>window.ZIVOZONE?.Economy?.open?.(),daily:()=>window.ZIVOZONE?.Daily?.open?.(),missions:()=>window.ZIVOZONE?.Missions?.open?.(),competition:()=>window.ZIVOZONE?.Competition?.open?.(),achievements:()=>window.ZIVOZONE?.Achievements?.open?.(),mining:()=>$('#zivo-header-mining')?.click()};try{fn[id]?.()}catch(e){console.warn('ZIVO Player Home action',e)}}
function missionData(){const s=missions(),items=s.items||{},rows=Object.entries(items).map(([id,v])=>({id,goal:Number(v.goal)||0,value:Number(v.value)||0,claimed:!!s.claimed?.[id]}));return{rows,done:rows.filter(x=>x.value>=x.goal).length,total:rows.length,next:rows.find(x=>x.value<x.goal&&!x.claimed)||rows[0]}}
function liveSummary(){const m=sports();const live=m.filter(x=>x.status==='LIVE');const next=m.filter(x=>x.status==='UPCOMING').sort((a,b)=>new Date(a.date)-new Date(b.date))[0];return{live,next}}
function activityRows(){const map={CHALLENGE_COMPLETED:['🎯','أكملت تحديًا'],REWARD_GRANTED:['🎁','حصلت على مكافأة'],MINING_COMPLETED:['⛏️','أكملت التعدين'],ACHIEVEMENT_UNLOCKED:['🏅','فتحت إنجازًا'],MISSION_UPDATED:['📋','حدّثت مهمة'],MATCH_UPDATED:['⚽','تحديث مباريات'],AUTH_CHANGED:['👤','تم تحديث الحساب']};return events().slice(-8).reverse().map(e=>({icon:map[e.eventName]?.[0]||'•',label:map[e.eventName]?.[1]||e.eventName,at:e.at}));}
function render(){if(!root)return;const p=player(),w=wallet(),c=competition(),a=achievements(),m=missionData(),ls=liveSummary(),u=user();const xp=Number(p.xp)||0,lvl=Number(p.level)||levelFor(xp),li=levelInfo(xp,lvl),z=Number(w.zivo)||Number(p.balance)||0,streak=Math.max(Number(p.streak)||0,Number(c.streak)||0),earned=(a.unlocked||[]).length;const next=m.next;const name=u?.displayName||u?.email?.split('@')[0]||p.name||'لاعب ZIVO';const avatar=u?.photoURL?`<img src="${esc(u.photoURL)}" alt="">`:'Z';
root.innerHTML=`<div class="zph-shell" dir="rtl" role="dialog" aria-modal="true" aria-labelledby="zph-title">
<header class="zph-header"><div class="zph-identity"><div class="zph-avatar">${avatar}</div><div><span class="zph-kicker">ZIVOZONE · بيت اللاعب · V${VERSION}</span><h2 id="zph-title">رحلة اللاعب</h2><p>${esc(name)} <span>•</span> ${u?esc(u.email||'حساب متصل'):'زائر — سجّل الدخول لحفظ رحلتك'}</p></div></div><div class="zph-head-tools"><span class="zph-sync ${cloud()?'on':''}">${cloud()?'● متصل بالسحابة':'○ وضع محلي'}</span><button data-zph="close" aria-label="إغلاق">×</button></div></header>
<section class="zph-hero"><div class="zph-hero-copy"><span>بيت اللاعب</span><h3>كل ما تبنيه في ZIVOZONE يبدأ من هنا.</h3><p>مستواك، نتائجك، ZIVO، مهامك، إنجازاتك، ومداخل عالم ZIVOZONE في مركز واحد.</p><div class="zph-hero-actions"><button class="primary" data-zph="challenges">🎯 أكمل رحلتي</button><button data-zph="profile">👤 ملف اللاعب</button></div></div><div class="zph-level"><div><small>المستوى</small><strong>${lvl}</strong><b>${xp} XP</b></div><div class="zph-progress"><i style="width:${li.pct}%"></i></div><span>${Math.round(li.pct)}% نحو المستوى ${lvl+1}</span></div></section>
<section class="zph-stats"><article class="gold"><span>🪙</span><small>الرصيد</small><b>${fmt(z)} <em>ZIVO</em></b></article><article><span>🎯</span><small>التحديات</small><b>${Number(p.games)||0}</b></article><article><span>🔥</span><small>السلسلة</small><b>${streak} <em>يوم</em></b></article><article><span>🏆</span><small>أفضل نتيجة</small><b>${Number(p.bestScore)||0}</b></article><article><span>🏅</span><small>الإنجازات</small><b>${earned}</b></article><article><span>⚡</span><small>مهام اليوم</small><b>${m.done}/${m.total}</b></article></section>
<section class="zph-grid">
<div class="zph-panel zph-today"><header><div><span class="zph-label">TODAY</span><h3>خطوتك التالية</h3></div><button data-zph="refresh">↻</button></header>${next?`<div class="zph-next"><div class="zph-next-icon">${next.id==='correct'?'🧠':next.id==='speed'?'⚡':'🎯'}</div><div><b>${next.id==='correct'?'أجب عن 5 إجابات صحيحة':next.id==='speed'?'أجب بسرعة':'أكمل تحديًا'}</b><small>${next.value}/${next.goal} مكتملة</small><div><i style="width:${Math.min(100,next.value/Math.max(1,next.goal)*100)}%"></i></div></div><button data-zph="${next.id==='play'?'challenges':'missions'}">ابدأ</button></div>`:`<div class="zph-empty-mini">أنجزت مهام اليوم. عد غدًا لبناء يوم جديد.</div>`}</div>
<div class="zph-panel zph-live"><header><div><span class="zph-label">SPORTS</span><h3>نبض العالم</h3></div><button data-zph="sports">كل المباريات</button></header><div class="zph-live-row"><strong>${ls.live.length}</strong><span>مباراة مباشرة الآن</span>${ls.live.length?'<b>🔴 LIVE</b>':'<em>لا يوجد مباشر الآن</em>'}</div>${ls.next?`<div class="zph-next-match"><span>${esc(ls.next.leagueName||'مباراة قادمة')}</span><b>${esc(ls.next.home?.name||'—')} × ${esc(ls.next.away?.name||'—')}</b></div>`:''}</div>
</section>
<section class="zph-destinations"><header><div><span class="zph-label">YOUR ZIVOZONE</span><h3>عالمك</h3></div><small>كل وجهة مرتبطة برحلتك</small></header><div class="zph-dest-grid">
<button data-zph="challenges"><span>🎯</span><b>التحديات</b><small>ارفع XP ونتائجك</small></button><button data-zph="daily"><span>📅</span><b>تحدي اليوم</b><small>ابنِ عادتك اليومية</small></button><button data-zph="missions"><span>📋</span><b>مهامي</b><small>${m.done}/${m.total} اليوم</small></button><button data-zph="competition"><span>🏆</span><b>المنافسة</b><small>${streak} يوم متواصل</small></button><button data-zph="achievements"><span>🏅</span><b>إنجازاتي</b><small>${earned} إنجاز</small></button><button data-zph="wallet"><span>🪙</span><b>محفظتي</b><small>${fmt(z)} ZIVO</small></button><button data-zph="mining"><span>⛏️</span><b>التعدين</b><small>ابنِ رصيدك</small></button><button data-zph="identity"><span>🧠</span><b>من أنا؟</b><small>اكتشف نمطك</small></button><button data-zph="sports"><span>⚽</span><b>الرياضة</b><small>مباريات وأخبار</small></button><button data-zph="ai"><span>🤖</span><b>ZIVO AI</b><small>اسأل عن رحلتك</small></button>
</div></section>
<section class="zph-bottom"><div class="zph-panel"><header><div><span class="zph-label">ACTIVITY</span><h3>آخر ما أنجزته</h3></div></header>${activityRows().length?`<div class="zph-activity">${activityRows().map(x=>`<div><span>${x.icon}</span><b>${esc(x.label)}</b><small>${new Date(x.at).toLocaleTimeString('ar-JO',{hour:'2-digit',minute:'2-digit'})}</small></div>`).join('')}</div>`:'<div class="zph-empty-mini">ابدأ أول تحدٍ لتظهر رحلتك هنا.</div>'}</div><div class="zph-panel zph-identity-card"><header><div><span class="zph-label">PLAYER CARD</span><h3>بطاقة لاعبك</h3></div></header><div class="zph-card-code"><strong>ZIVOZONE</strong><span>${esc(name)}</span><b>LV ${lvl} · ${xp} XP · ${fmt(z)} ZIVO</b></div><button class="primary" data-zph="profile">فتح الملف الكامل</button></div></section>
<footer class="zph-footer"><span>رحلتك ملكك — كل نتيجة تضيف شيئًا جديدًا إلى ملف اللاعب.</span><span>V${VERSION} · PLAYER HOME CORE</span></footer>
</div>`;bind();}
function bind(){root.querySelectorAll('[data-zph]').forEach(b=>b.onclick=()=>{const id=b.dataset.zph;if(id==='close')close();else if(id==='refresh')render();else go(id)});}
function open(){if(!root){root=document.createElement('div');root.id='zivo-player-home';root.className='zph-overlay';document.body.appendChild(root);root.addEventListener('click',e=>{if(e.target===root)close()});document.addEventListener('keydown',e=>{if(e.key==='Escape'&&root?.classList.contains('open'))close()});}
render();root.classList.add('open');document.body.classList.add('zivo-player-home-open');clearInterval(timer);timer=setInterval(()=>{if(root?.classList.contains('open'))render()},15000);
const E=window.ZIVOZONE?.Events;if(E){['PLAYER_UPDATED','WALLET_UPDATED','MINING_COMPLETED','CHALLENGE_COMPLETED','REWARD_GRANTED','MISSION_UPDATED','ACHIEVEMENT_UNLOCKED','MATCH_UPDATED'].forEach(n=>unsubs.push(E.on(n,()=>{if(root?.classList.contains('open'))render()})))} }
function mount(){const host=document.querySelector('.topbar .top-actions');if(host&&!document.getElementById('zivo-player-home-launch')){const b=document.createElement('button');b.id='zivo-player-home-launch';b.className='zph-launch';b.type='button';b.innerHTML='<span>⚡</span><b>رحلة اللاعب</b>';b.onclick=open;host.insertBefore(b,host.firstChild)}
const nav=document.querySelector('.main-nav a[data-player-home]');if(nav){nav.textContent='رحلة اللاعب';nav.removeAttribute('data-i18n');nav.onclick=e=>{e.preventDefault();open()}}
}
window.ZIVOZONE=window.ZIVOZONE||{};window.ZIVOZONE.PlayerHub=Object.freeze({open,close,render,refresh:render,version:VERSION,canonical:true});
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
})();
