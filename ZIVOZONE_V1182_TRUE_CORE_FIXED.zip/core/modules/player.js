/* ZIVOZONE V1180 — Canonical Player Core
   Migrates V30 + V35 into one in-site Player/Progress service. */
(() => {
  'use strict';
  const ID_KEY='zivozone_v30_identity';
  const PROGRESS_KEY='zivozone_v35_progress';
  const read=(k,f={})=>{try{const v=localStorage.getItem(k);return v?JSON.parse(v):f}catch(_){return f}};
  const write=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));return true}catch(_){return false}};
  const clean=s=>String(s||'لاعب ZIVO').replace(/[<>"'`]/g,'').trim().slice(0,24)||'لاعب ZIVO';
  const user=()=>{try{return window.firebase?.auth?.()?.currentUser||null}catch(_){return null}};
  const day=()=>new Date().toISOString().slice(0,10);
  const state=()=>{let s=read(PROGRESS_KEY,{});if(!s.version)s={version:1,xp:0,level:1,played:0,correct:0,streak:0,lastDay:null,bestScore:0,history:[]};return s};
  const levelFor=x=>Math.max(1,Math.floor(Math.sqrt(Math.max(0,x)/100))+1);
  function addXP(amount=0){const s=state();s.xp=Math.max(0,s.xp+Math.max(0,Number(amount)||0));s.level=levelFor(s.xp);write(PROGRESS_KEY,s);window.dispatchEvent(new CustomEvent('zivozone-xp',{detail:{xp:Number(amount)||0}}));return s;}
  function addProgress(xp=0,correct=0,score=0){
    const s=state(),d=day();
    if(s.lastDay!==d){const y=new Date(d+'T00:00:00');y.setUTCDate(y.getUTCDate()-1);const yd=y.toISOString().slice(0,10);s.streak=s.lastDay===yd?s.streak+1:1;s.lastDay=d;}
    s.xp=Math.max(0,s.xp+Math.max(0,Number(xp)||0));s.played++;s.correct+=Math.max(0,Number(correct)||0);s.bestScore=Math.max(Number(s.bestScore)||0,Number(score)||0);s.level=levelFor(s.xp);s.history=(s.history||[]).slice(-19);s.history.push({date:d,xp:s.xp,level:s.level});write(PROGRESS_KEY,s);window.dispatchEvent(new CustomEvent('zivozone-progress',{detail:{xp:Number(xp)||0,correct:Number(correct)||0,score:Number(score)||0}}));return s;
  }
  const challengeStats=()=>read(ID_KEY,{}).challengeStats||{};
  function record(d={}){const old=read(ID_KEY,{}),all=challengeStats(),key=String(d.challenge||'general').slice(0,60),q=all[key]||{games:0,correct:0,total:0,best:0};q.games++;q.correct+=Number(d.correct)||0;q.total+=Number(d.total)||0;q.best=Math.max(q.best,Number(d.score)||0);all[key]=q;old.challengeStats=all;old.name=old.name||'لاعب ZIVO';write(ID_KEY,old);return q;}
  function get(){const p=state(),old=read(ID_KEY,{}),u=user(),wallet=window.ZIVOZONE?.Economy?.getWallet?.()||window.ZIVOZONE?.Economy?.getWallet?.()||{};return {...old,name:clean(u?.displayName||old.name),level:Number(p.level)||1,xp:Number(p.xp)||0,games:Number(p.played??p.games)||0,balance:Number(wallet.zivo)||Number(old.balance)||0,bestScore:Number(p.bestScore)||0,streak:Number(p.streak)||0,challengeStats:challengeStats()};}
  function renderMain(){const s=get();const set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=String(v)};set('profile-name',s.name||'زائر');set('profile-email',user()?.email||'يمكنك اللعب كزائر ثم إنشاء حساب لحفظ تقدمك.');set('profile-level',s.level);set('profile-xp',s.xp);set('profile-coins',s.balance);set('profile-wins',s.games);set('profile-best-streak',s.streak);const bar=document.getElementById('xp-progress');if(bar){const base=(s.level-1)*100,next=s.level*100;bar.style.width=Math.min(100,Math.max(0,((s.xp-base)/(next-base))*100))+'%';}}
  window.ZIVOZONE=window.ZIVOZONE||{};
  window.ZIVOZONE.Player=Object.freeze({get,state,progress:state,levelFor,addProgress,addXP,record,stats:challengeStats,render:renderMain,sanitizeName:clean});
  window.ZIVOZONE.Progress=Object.freeze({state,add:addProgress,levelFor});
  window.addEventListener('zivozone-result',e=>{const d=e.detail||{};if(d.__coreProgressApplied)return;d.__coreProgressApplied=true;addProgress(Number(d.xp)||Math.max(0,(Number(d.correct)||0)*10),Number(d.correct)||0,Number(d.score)||0);record(d);});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',renderMain);else renderMain();
})();
