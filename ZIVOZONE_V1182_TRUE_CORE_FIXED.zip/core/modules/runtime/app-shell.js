/* ZIVOZONE — app-shell.js
   App shell bootstrap: routing, view mounting, global UI wiring
   Extracted verbatim from the former core/runtime.js monolith (V1180 refactor). No logic changed.
*/
/* ===== app.js ===== */
/* ============================================================
   ZIVOZONE APP ENGINE V8
   - Firebase preserved
   - Guest play preserved
   - Unique challenge sessions
   - Mixed question types
   - Continuous challenge-only audio
   - Dark Room infinite psychological mode
============================================================ */
(() => {
  'use strict';
  const A=window.ZIVOZONE_AUTH,I=window.ZIVOZONE_I18N;
  const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
  const LS='zivozone_identity_v1';
  const ADMIN_EMAIL=window.ZIVOZONE_CONFIG.ADMIN_EMAIL_NORMALIZED;
  const ADMIN_NAME='رائف البطوش';
  const API=window.ZIVOZONE_API||{};
  let state={level:1,xp:0,coins:0,wins:0,gamesPlayed:0,bestStreak:0,identity:null};
  const QUESTION_TIME=30;
  let questionTimer=null;
  let questionDeadline=0;
  let lastTickSecond=null;
  let identityTimer=null;
  let identityDeadline=0;
  const t=k=>I.tr(k),lang=()=>I.get(),S=()=>window.ZIVOZONE_AUDIO||{},O=(ar,en)=>({ar,en,zh:en,hi:en,es:en});
  const esc=s=>{const d=document.createElement('div');d.textContent=String(s??'');return d.innerHTML};
  const loc=o=>typeof o==='string'?o:(o?.[lang()]||o?.en||o?.ar||'');
  const toast=(msg,type='info')=>{const box=$('#toast-container');if(!box)return;const x=document.createElement('div');x.className='toast '+type;x.textContent=msg;box.appendChild(x);setTimeout(()=>x.remove(),3200)};
  const loadState=()=>{try{state.identity=JSON.parse(localStorage.getItem(LS)||'null')}catch(e){state.identity=null}};
  const saveState=()=>{try{if(state.identity)localStorage.setItem(LS,JSON.stringify(state.identity));else localStorage.removeItem(LS)}catch(e){}};
  function syncFromPlayer(){const p=A.getPlayer();if(!p)return;state={...state,xp:Number(p.xp)||0,coins:Number(p.coins)||0,wins:Number(p.wins)||0,gamesPlayed:Number(p.gamesPlayed)||0,level:Number(p.level)||1,bestStreak:Number(p.bestStreak)||Number(state.bestStreak)||0};saveState()}
  function profile(){
    const p=A.getPlayer(),u=A.getUser?.(),admin=A.isAdmin?.()||String(u?.email||'').trim().toLowerCase()===ADMIN_EMAIL,l=Number(state.level)||Number(p?.level)||1;
    const chip=$('#player-level-chip'); if(chip) chip.textContent=admin?'ADMIN':`${t('level')} ${l}`;
    const login=$('#login-btn'); if(login) login.textContent=admin?'👑 ADMIN':A.isLoggedIn()?`👤 ${p?.name||t('profile')}`:t('login');
  }
  function clearIdentityTimer(){
    if(identityTimer){clearInterval(identityTimer);identityTimer=null}
    identityDeadline=0;
  }
  function updateTimerUI(seconds){
    const n=Math.max(0,Math.ceil(seconds));
    const bar=$('#question-timer-fill'),num=$('#question-timer-number'),box=$('#question-timer');
    if(bar)bar.style.width=Math.max(0,Math.min(100,(seconds/QUESTION_TIME)*100))+'%';
    if(num)num.textContent=n;
    if(box)box.classList.toggle('urgent',n<=3);
  }
  function startQuestionTimer(){
    clearQuestionTimer();
    game.questionStartedAt=Date.now();
    questionDeadline=game.questionStartedAt+QUESTION_TIME*1000;
    updateTimerUI(QUESTION_TIME);
    questionTimer=setInterval(()=>{
      const left=(questionDeadline-Date.now())/1000;
      updateTimerUI(left);
      const n=Math.max(0,Math.ceil(left));
      if(n<=3 && n!==lastTickSecond){lastTickSecond=n;S().tick?.()}
      if(left<=0){clearQuestionTimer();timeoutQuestion()}
    },120);
  }
  function remainingSeconds(){
    if(!questionDeadline)return 0;
    return Math.max(0,Math.min(QUESTION_TIME,(questionDeadline-Date.now())/1000));
  }
  function speedBonus(ok,seconds){
    if(!ok)return 0;
    const speed=Math.round(Math.max(0,Math.min(QUESTION_TIME,seconds))*5);
    const streakBonus=Math.max(0,(game.streak-1))*5;
    return 50+speed+streakBonus;
  }
  function registerPressure(ok,seconds,timeout=false){
    if(ok){
      game.streak+=1;
      game.bestStreak=Math.max(game.bestStreak,game.streak);
      game.pressureScore+=(speedBonus(true,seconds));
    }else{
      game.streak=0;
    }
    if(timeout)game.timedOut=(game.timedOut||0)+1;
  }
  function timeoutQuestion(){
    if(game.locked)return;
    game.locked=true;
    const q=currentQ();
    if(!q)return;
    game.answers.push({id:q.id,value:null,ok:false,timeout:true,seconds:0,pressure:0});
    registerPressure(false,0,true);
    S().timeout?.();
    const buttons=$$('.answer');
    buttons.forEach(b=>b.disabled=true);
    const input=$('#answer-input');
    if(input)input.disabled=true;
    const form=$('#answer-form');
    if(form)form.classList.add('input-timeout');
    nextQuestion(420);
  }
  function startIdentityTimer(){
    clearIdentityTimer();
    identityDeadline=Date.now()+QUESTION_TIME*1000;
    const paint=()=>{
      const left=(identityDeadline-Date.now())/1000;
      const bar=$('#identity-timer-fill'),num=$('#identity-timer-number'),box=$('#identity-timer');
      if(bar)bar.style.width=Math.max(0,Math.min(100,(left/QUESTION_TIME)*100))+'%';
      if(num)num.textContent=Math.max(0,Math.ceil(left));
      if(box)box.classList.toggle('urgent',Math.ceil(left)<=3);
      if(left<=3)S().tick?.();
      if(left<=0){clearIdentityTimer();identityTimeout()}
    };
    paint();
    identityTimer=setInterval(paint,250);
  }
  function identityTimeout(){
    const buttons=$$('.id-choice');
    buttons.forEach(b=>b.disabled=true);
    S().timeout?.();
    // A timeout records no trait preference and moves to the next item.
    window.__zivoIdentityTimeout=true;
    setTimeout(()=>buttons[0]?.click(),180);
  }
  function returnToChallenges(){S().stopChallenge?.();if('speechSynthesis' in window)try{speechSynthesis.cancel()}catch(e){}document.body.classList.remove('horror-active');closeModal();location.hash='#challenges';$('#challenges')?.scrollIntoView({behavior:'smooth'})}
  function openModal(html,cls=''){const r=$('#modal-root');r.innerHTML=`<div class="modal-backdrop"><div class="modal-card ${cls}" role="dialog" aria-modal="true">${html}</div></div>`;r.setAttribute('aria-hidden','false');r.querySelectorAll('[data-close]').forEach(b=>b.onclick=closeModal);const bg=r.querySelector('.modal-backdrop');if(bg)bg.onclick=e=>{if(e.target===bg)closeModal()}}
  function openTerms(){let o=document.getElementById('zivo-terms-modal');if(!o){o=document.createElement('div');o.id='zivo-terms-modal';o.className='zivo-legal-overlay';o.innerHTML=`<div class="zivo-legal-card" dir="rtl"><button class="zivo-legal-close">×</button><span class="eyebrow">ZIVOZONE · TERMS</span><h2>شروط استخدام ZIVOZONE</h2><p>آخر تحديث: 11 سبتمبر 2026 · الإصدار: ZIVO-TERMS-2026.09</p><div class="zivo-legal-body"><h3>1. قبول الشروط</h3><p>بإنشاء حساب أو استخدام المنصة، يقر المستخدم بأنه قرأ هذه الشروط ووافق عليها. إذا لم يوافق عليها، فلا يجوز له إنشاء حساب أو استخدام الميزات التي تتطلب حسابًا.</p><h3>2. طبيعة ZIVO</h3><p><b>ZIVO هي وحدة افتراضية داخل منصة ZIVOZONE فقط.</b> لا تمثل عملة قانونية أو وديعة أو سهمًا أو استثمارًا أو ضمانًا ماليًا، ولا يوجد بموجب هذه الشروط حق تلقائي في استبدالها نقدًا أو تحويلها إلى أموال أو عملات خارجية. لا يجوز بيعها أو شراؤها أو تداولها خارج الأنظمة التي تعتمدها ZIVOZONE رسميًا.</p><h3>3. التعدين والمكافآت</h3><p>مكافآت التعدين والتحديات تخضع لقواعد المنصة وحدودها، ويمكن لـ ZIVOZONE تعديل معدلات المكافآت أو إيقافها أو تعليق الحسابات المخالفة لحماية المنصة والمستخدمين. الرصيد المعروض داخل الحساب هو رصيد افتراضي للمنصة.</p><h3>4. الحساب والأمان</h3><p>المستخدم مسؤول عن بيانات تسجيل الدخول وعن الأنشطة التي تتم من حسابه. يمنع إنشاء حسابات أو استخدام أدوات آلية بقصد التلاعب بالمكافآت أو الترتيب أو البيانات.</p><h3>5. الاستخدام المقبول</h3><p>يمنع الاحتيال، واستغلال الثغرات، والهجمات الآلية، وإساءة استخدام المحتوى أو الخدمات، وانتحال صفة المدير أو أي مستخدم آخر، ومحاولة الوصول إلى بيانات غير مصرح بها.</p><h3>6. المحتوى والخدمات</h3><p>قد تتغير الألعاب والتحديات والأخبار والميزات بمرور الوقت. لا نضمن توفر كل خدمة دون انقطاع، ونبذل جهودًا معقولة للحفاظ على استقرار المنصة.</p><h3>7. الأخبار والروابط الخارجية</h3><p>الأخبار والروابط الخارجية مقدمة للعرض والمعلومات، وتخضع للمصادر الخارجية وشروطها. لا تتحمل ZIVOZONE مسؤولية محتوى المواقع الخارجية.</p><h3>8. الخصوصية</h3><p>تُستخدم بيانات الحساب واللعب اللازمة لتشغيل المنصة وحفظ التقدم والأمان والتحليلات التشغيلية وفق سياسة الخصوصية التي تعتمدها ZIVOZONE.</p><h3>9. التعديلات والإنهاء</h3><p>يجوز تحديث الشروط أو تعديل الميزات عند الحاجة. استمرار الاستخدام بعد نشر التحديث يعني قبول الشروط المعدلة ضمن الحدود التي يسمح بها القانون المعمول به.</p><h3>10. القانون والحقوق</h3><p>تُطبَّق هذه الشروط بما لا يخالف القوانين الإلزامية المعمول بها. هذه صياغة تشغيلية عامة وليست بديلاً عن مراجعة محامٍ قبل الإطلاق التجاري أو تقديم خدمات مالية.</p></div><div class="zivo-legal-actions"><button class="btn btn-primary zivo-legal-close">فهمت</button></div></div>`;document.body.appendChild(o);o.querySelectorAll('.zivo-legal-close').forEach(b=>b.onclick=()=>o.remove());o.onclick=e=>{if(e.target===o)o.remove()}}else{o.style.display='grid'}}
  window.ZIVOZONE_OPEN_TERMS=openTerms;
  function authModal(after){
    let mode='register';
    const render=()=>{
      const isReset=mode==='reset';
      const title=mode==='register'?t('register'):mode==='login'?t('welcomeBack'):t('resetTitle');
      const hint=mode==='register'?t('registerHint'):mode==='login'?t('loginHint'):t('resetHint');
      openModal(`<button class="modal-close" data-close>×</button><span class="eyebrow">${t('account')}</span><h2>${title}</h2><p class="muted">${hint}</p>${isReset?'':`<div class="auth-tabs"><button id="tab-register" class="btn ${mode==='register'?'btn-primary':''}">${t('register')}</button><button id="tab-login" class="btn ${mode==='login'?'btn-primary':''}">${t('signIn')}</button></div>`}<form id="auth-form">${mode==='register'?`<div><label>${t('playerName')}</label><input id="auth-name" minlength="2" required placeholder="${esc(t('yourName'))}"></div><div><label>${t('age')}</label><input id="auth-age" type="number" min="5" max="100" required value="18"></div>`:''}<div><label>${t('email')}</label><input id="auth-email" type="email" required placeholder="${esc(t('emailPlaceholder'))}"></div>${isReset?'':`<div><label>${t('password')}</label><input id="auth-pass" type="password" minlength="6" required placeholder="${esc(t('passwordPlaceholder'))}"></div>`}${mode==='register'?`<label class="zivo-terms-check"><input id="auth-terms" type="checkbox" required><span>أوافق على <button type="button" id="open-terms" class="zivo-inline-link">شروط استخدام ZIVOZONE</button> وسياسة الاستخدام، وأفهم أن ZIVO رصيد افتراضي داخل المنصة فقط وليس نقودًا أو استثمارًا.</span></label>`:''}<button class="btn btn-primary full" type="submit">${mode==='register'?t('createAccount'):mode==='login'?t('signIn'):t('sendReset')}</button></form>${mode==='login'?`<button type="button" id="forgot-pass" class="zivo-inline-link zivo-forgot-link">${t('forgotPassword')}</button>`:''}${isReset?`<button type="button" id="back-to-login" class="zivo-inline-link zivo-forgot-link">${t('backToLogin')}</button>`:''}</div>`);
      $('#tab-register')?.addEventListener('click',()=>{mode='register';render()});
      $('#tab-login')?.addEventListener('click',()=>{mode='login';render()});
      $('#open-terms')?.addEventListener('click',openTerms);
      $('#forgot-pass')?.addEventListener('click',()=>{mode='reset';render()});
      $('#back-to-login')?.addEventListener('click',()=>{mode='login';render()});
      $('#auth-form').onsubmit=async e=>{
        e.preventDefault();
        try{
          if(mode==='register'){
            await A.register({name:$('#auth-name').value,age:$('#auth-age').value,email:$('#auth-email').value,password:$('#auth-pass').value,termsAccepted:$('#auth-terms')?.checked===true});
            await A.setLanguage(lang());closeModal();syncFromPlayer();profile();toast(t('success'),'success');if(after)after();
          }else if(mode==='login'){
            await A.login($('#auth-email').value,$('#auth-pass').value);
            await A.setLanguage(lang());closeModal();syncFromPlayer();profile();toast(t('success'),'success');if(after)after();
          }else{
            await A.resetPassword($('#auth-email').value);
            toast(t('resetSent'),'success');
            mode='login';render();
          }
        }catch(err){toast(err.message||t('firebaseError'),'error')}
      };
    };
    render();
  }
  /* Challenge execution is owned exclusively by core/modules/challenges.js. */
  function identity(){
    const qs=[
      ['عندما تبدأ مشروعًا جديدًا، ما أول شيء تفعله؟','When starting a new project, what do you do first?',['أضع خطة واضحة','أبدأ بالتجربة','أجمع الناس حول الفكرة','أبحث عن فرصة مختلفة'],['Make a clear plan','Start experimenting','Bring people around the idea','Look for a different opportunity']],
      ['عندما تفشل في شيء مهم؟','When you fail at something important?',['أحلل السبب','أحاول مرة أخرى بسرعة','أطلب رأيًا من شخص أثق به','أحوّل الفشل إلى فكرة جديدة'],['Analyze the reason','Try again quickly','Ask someone I trust','Turn failure into a new idea']],
      ['في المنافسة، ما الذي يشغلك أكثر؟','In competition, what matters most to you?',['الدقة','السرعة','الفريق','المفاجأة والإبداع'],['Accuracy','Speed','The team','Surprise and creativity']],
      ['عندما يختلف الناس معك؟','When people disagree with you?',['أناقش الأدلة','أدافع عن قراري','أبحث عن حل للجميع','أغير زاوية التفكير'],['Discuss the evidence','Defend my decision','Find a solution for everyone','Change the angle']],
      ['أي وصف أقرب لك؟','Which description fits you best?',['تحليلي','حاسم','اجتماعي','مغامر'],['Analytical','Decisive','Social','Adventurous']],
      ['عندما يكون الوقت ضيقًا؟','When time is tight?',['أرتب الأولويات','أتصرف فورًا','أوزع المهام','أخاطر بحل غير تقليدي'],['Prioritize','Act immediately','Delegate tasks','Risk an unconventional solution']],
      ['في لعبة صعبة جدًا؟','In a very difficult game?',['أبحث عن النمط','أضغط حتى النهاية','أفكر مع الآخرين','أجرب شيئًا لم أجربه'],['Find the pattern','Push to the end','Think with others','Try something new']],
      ['ما الذي يجذبك أكثر؟','What attracts you most?',['الألغاز','التحدي','الناس','المجهول'],['Puzzles','Challenge','People','The unknown']],
      ['إذا تغيرت الخطة فجأة؟','If the plan suddenly changes?',['أعيد الحساب','أقرر بسرعة','أشاور الفريق','أستمتع بالفوضى'],['Recalculate','Decide quickly','Consult the team','Enjoy the chaos']],
      ['ما الذي تعتبره نقطة قوة؟','What do you consider a strength?',['التركيز','الشجاعة','التواصل','الخيال'],['Focus','Courage','Communication','Imagination']],
      ['في المجموعة غالبًا أنت؟','In a group you are usually?',['المحلل','القائد','المساند','صاحب الأفكار'],['The analyst','The leader','The supporter','The idea person']],
      ['عند اتخاذ قرار كبير؟','When making a major decision?',['أقارن الخيارات','أحسم بسرعة','أفكر في تأثيره على الناس','أثق بحدسي'],['Compare options','Decide quickly','Think about its impact on people','Trust my intuition']],
      ['أي نوع من المخاطر تفضّل؟','Which risk do you prefer?',['المحسوب','الجريء','المشترك','المبتكر'],['Calculated','Bold','Shared','Innovative']],
      ['ماذا تفعل عندما يمل الآخرون؟','What do you do when others get bored?',['أضيف هدفًا جديدًا','أرفع التحدي','أشرك الجميع','أقلب القواعد'],['Add a new goal','Raise the challenge','Involve everyone','Change the rules']],
      ['ما الذي يزعجك أكثر؟','What bothers you most?',['الفوضى بلا منطق','التردد','العزلة','الروتين'],['Meaningless chaos','Hesitation','Isolation','Routine']],
      ['إذا أعطاك شخص سرًا؟','If someone gives you a secret?',['أحفظه','أحميه مهما كان','أفهم مشاعره','أستخدمه لفهم الصورة'],['Keep it','Protect it no matter what','Understand their feelings','Use it to understand the picture']],
      ['كيف تتعلم شيئًا جديدًا؟','How do you learn something new?',['أفهم القاعدة','أجرب بيدي','أتعلم مع شخص','أكسر الطريقة المعتادة'],['Understand the rule','Try it myself','Learn with someone','Break the usual method']],
      ['في لحظة ضغط حقيقية؟','In a truly stressful moment?',['أهدأ وأحلل','أواجه','أطلب الدعم','أبحث عن مخرج غير متوقع'],['Calm down and analyze','Confront it','Ask for support','Find an unexpected way out']],
      ['ما الذي تريد أن يذكرك الناس به؟','What do you want people to remember about you?',['عقلي','قوتي','قلبي','أفكاري'],['My mind','My strength','My heart','My ideas']],
      ['لو فتحت لك بوابة مجهولة؟','If an unknown portal opened for you?',['أفحصها أولًا','أدخل فورًا','أسأل من معي','أدخل لأكتشف ما وراءها'],['Inspect it first','Enter immediately','Ask whoever is with me','Enter to discover what is beyond']]
    ];
    const traits=[t('analysis'),t('adventurer'),t('teamPlayer'),t('creative')];
    const traitEn=['analyst','leader','connector','explorer'];
    const paragraphs={
      ar:['أنت شخص تحليلي، تراقب التفاصيل قبل القرار، وتبحث عن الأنماط الخفية. قوتك في الهدوء، التركيز، وتحويل التعقيد إلى خطوات قابلة للفهم.','أنت حاسم وطموح، تميل للمبادرة وتحمل الضغط. لا تنتظر الظروف المثالية، بل تتحرك عندما يتردد الآخرون وتحوّل التحدي إلى فرصة.','أنت اجتماعي وداعم، ترى الناس جزءًا أساسيًا من النجاح. تعرف كيف تجمع الآراء، تبني الثقة، وتحافظ على الفريق متماسكًا وقت الضغط.','أنت مستكشف ومبدع، يثيرك المجهول وتكره القوالب الثابتة. تميل لتجربة طرق غير مألوفة وتحويل الأفكار الغريبة إلى فرص جديدة.'],
      en:['You are analytical, observant, and patient, searching for hidden patterns before acting. Your strength is turning complexity into clear, useful decisions.','You are decisive and ambitious, comfortable under pressure. You act when others hesitate, turning uncertainty into momentum and difficult moments into opportunities.','You are social and supportive, seeing people as part of success. You build trust, connect perspectives, and help groups stay strong when pressure rises.','You are curious and creative, energized by uncertainty and new paths. You challenge routines, test unusual ideas, and turn strange possibilities into opportunities.']
    };
    let i=0,s=[0,0,0,0];
    window.__zivoIdentityTimeout=false;
    const step=()=>{
      if(i>=qs.length){const m=s.indexOf(Math.max(...s));state.identity=traits[m];saveState();const p=(paragraphs[lang()]||paragraphs.en)[m];openModal(`<button class="modal-close" data-action="return-challenges">×</button><span class="eyebrow">${t('whoAmI')}</span><h2>${traits[m]}</h2><p class="identity-result">${esc(p)}</p><div class="identity-score-grid"><span>${traitEn[m]}</span><span>${s[m]} / 20</span></div><div class="modal-actions"><button class="btn btn-primary" data-action="return-challenges">${t('close')}</button></div>`,'identity-result-modal');return}
      const q=qs[i],question=lang()==='ar'?q[0]:q[1],options=lang()==='ar'?q[2]:q[3];
      openModal(`<button class="modal-close" data-action="return-challenges">×</button><span class="eyebrow">${t('whoAmI')} • ${i+1}/20</span><h2>${esc(question)}</h2><div id="identity-timer" class="question-timer" role="timer" aria-live="polite"><span class="timer-label">${esc(t('timeLeft'))}</span><strong id="identity-timer-number">10</strong><div class="question-timer-track"><span id="identity-timer-fill"></span></div></div><div class="question-progress"><span style="width:${((i+1)/20)*100}%"></span></div><div class="answers">${options.map((x,n)=>`<button class="btn btn-ghost id-choice" data-n="${n}">${esc(x)}</button>`).join('')}</div>`,'identity-test-modal');
      $$('.id-choice').forEach(b=>b.onclick=()=>{clearIdentityTimer();if(window.__zivoIdentityTimeout){window.__zivoIdentityTimeout=false;i++;step();return}s[Number(b.dataset.n)]++;i++;step()});
      startIdentityTimer();
    };step();
  }
  function renderChallenges(){window.ZIVOZONE?.Challenges?.renderCenter?.()}
  const NEWS=[{key:'FIFA',url:'https://www.fifa.com/',icon:'🌍',title:O('فيفا','FIFA')},{key:'AFC',url:'https://www.the-afc.com/',icon:'🏆',title:O('الاتحاد الآسيوي','AFC')},{key:'UEFA',url:'https://www.uefa.com/',icon:'⭐',title:O('يويفا','UEFA')},{key:'ESPN',url:'https://www.espn.com/',icon:'📰',title:O('ESPN','ESPN')}];
  function renderNewsSources(){const box=$('#news-list');if(!box)return;box.innerHTML=NEWS.map(n=>`<article class="sports-card"><div class="icon">${n.icon}</div><span class="card-tag">${n.key}</span><h3>${esc(loc(n.title))}</h3><p>${esc(t('sportsIntro'))}</p><a class="btn btn-ghost" href="${n.url}" target="_blank" rel="noopener noreferrer">${t('openNews')}</a></article>`).join('')}
  async function sports(){renderNewsSources();window.ZIVOZONE_NEWS?.load?.($('#news-list'),lang());window.ZIVOZONE_NEWS?.loadJordan?.($('#jordan-news-list'),lang());window.ZIVOZONE_FIXTURES?.load?.($('#fixture-list'),lang());}
  function localAIReply(q){const x=q.toLowerCase();if(x.includes('مستوى')||x.includes('level')||x.includes('等级')||x.includes('nivel'))return`${t('level')} ${state.level} — ${state.xp} XP, ${state.coins} ZIVO.`;if(x.includes('تحد')||x.includes('challenge')||x.includes('挑战')||x.includes('desaf'))return t('challengeText');if(x.includes('رياض')||x.includes('sport')||x.includes('体育')||x.includes('deporte'))return t('sportsIntro');return t('aiWelcome')}
  async function askAI(message){const payload={message:String(message||'').slice(0,1000),language:lang(),player:{level:state.level,xp:state.xp,gamesPlayed:state.gamesPlayed,coins:state.coins}};try{if(window.ZIVOZONE_REAL_AI?.ask){return await window.ZIVOZONE_REAL_AI.ask(message)}}catch(e){console.warn('ZIVO AI Gemini:',e);if(e?.message)toast(e.message,'error')}try{const f=window.firebase?.functions?.();if(f){const fn=f.httpsCallable(API.aiCallable||'zivoAI');const r=await fn(payload);if(r?.data?.reply)return r.data.reply}}catch(e){console.warn('ZIVO AI callable:',e)}if(API.aiEndpoint){try{const r=await fetch(API.aiEndpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});if(r.ok){const d=await r.json();if(d.reply)return d.reply}}catch(e){console.warn('ZIVO AI endpoint:',e)}}return localAIReply(message)}
  function applyLanguage(){const l=lang();document.documentElement.lang=l;document.documentElement.dir=I.dir[l];$$('[data-i18n]').forEach(el=>{const k=el.dataset.i18n;if(I.T[l]?.[k]!==undefined)el.textContent=t(k)});$$('[data-i18n-placeholder]').forEach(el=>el.placeholder=t(el.dataset.i18nPlaceholder));renderChallenges();renderNewsSources();profile();sports();$('#footer-tagline')?.replaceChildren(document.createTextNode(t('footerTagline')))}
  document.addEventListener('click',e=>{const gameBtn=e.target.closest('[data-game],[data-challenge]');if(gameBtn){e.preventDefault();const id=gameBtn.dataset.game||gameBtn.dataset.challenge;window.ZIVOZONE?.Challenges?.start?.(id)||window.ZIVOZONE_START_CHALLENGE?.(id);return}const action=e.target.closest('[data-action]')?.dataset.action;if(action==='scroll-games'||action==='scroll-challenges'){e.preventDefault();$('#challenges')?.scrollIntoView({behavior:'smooth'});return}if(action==='open-identity'){identity();return}if(action==='login'){A.isLoggedIn()?window.ZIVOZONE?.PlayerHub?.open?.():authModal();return}if(action==='logout'){A.logout().then(()=>{state={level:1,xp:0,coins:0,wins:0,gamesPlayed:0,bestStreak:0,identity:null};saveState();profile();toast(t('logoutDone'))});return}if(action==='refresh-sports'){sports();return}if(action==='ad-info'){toast(t('adText'));return}if(action==='ads-control'){window.ZIVOZONE_ADS?.open?.();return}if(action==='return-challenges'){returnToChallenges();return}if(action==='quit-game'){quitGame();return}});
  function bind(){const audioBtn=$('#audio-toggle');if(audioBtn){audioBtn.textContent=S().isEnabled?.()?'🔊':'🔇';audioBtn.onclick=async()=>{await S().unlock?.();S().toggle?.();audioBtn.textContent=S().isEnabled?.()?'🔊':'🔇'}}$('#language-select').value=lang();$('#language-select').onchange=async e=>{I.set(e.target.value);await A.setLanguage(e.target.value);applyLanguage();toast(t('updateDone'),'success')};const accountRoute=()=>A.isAdmin?.()?location.hash='#admin':A.isLoggedIn()?window.ZIVOZONE?.PlayerHub?.open?.():authModal();$('#login-btn').onclick=accountRoute;$$('[data-action="login"]').forEach(b=>b.onclick=accountRoute);$('#ai-form').onsubmit=async e=>{e.preventDefault();const input=$('#ai-input'),v=input.value.trim();if(!v)return;const box=$('#ai-messages');const u=document.createElement('div');u.className='ai-message user';u.textContent=v;box.append(u);input.value='';const b=document.createElement('div');b.className='ai-message bot';b.textContent='…';box.append(b);b.textContent=await askAI(v);box.scrollTop=box.scrollHeight};
    const navToggle=$('#zivo-nav-toggle'),mainNav=$('.main-nav');
    if(navToggle&&mainNav){
      const setOpen=v=>{document.body.classList.toggle('zivo-nav-open',v);navToggle.setAttribute('aria-expanded',String(v))};
      navToggle.onclick=()=>setOpen(!document.body.classList.contains('zivo-nav-open'));
      mainNav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>setOpen(false)));
      document.addEventListener('keydown',e=>{if(e.key==='Escape')setOpen(false)});
      document.addEventListener('click',e=>{if(document.body.classList.contains('zivo-nav-open')&&!mainNav.contains(e.target)&&e.target!==navToggle&&!navToggle.contains(e.target))setOpen(false)});
    }
  }
  window.addEventListener('zivozone-auth',e=>{syncFromPlayer();profile();const el=$('#firebase-status');if(el){el.textContent=e.detail?.cloud?'●':'○';el.classList.toggle('online',!!e.detail?.cloud);el.title=e.detail?.cloud?'Firebase connected':'Guest/local mode'}});
  window.addEventListener('zivozone-auth',()=>{A.touchSession?.();A.flushAttempts?.();});
  window.addEventListener('hashchange',()=>A.touchSession?.());
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)A.touchSession?.()});
  setInterval(()=>{if(!document.hidden)A.touchSession?.();},5*60*1000);
  window.addEventListener('zivozone-language',()=>{const sel=$('#language-select');if(sel)sel.value=lang()});
  loadState();document.addEventListener('DOMContentLoaded',()=>{
  try{bind()}catch(e){console.error('ZIVOZONE bind error:',e)}
  try{applyLanguage()}catch(e){console.error('ZIVOZONE render error:',e)}
  setTimeout(()=>$('#app-loader')?.classList.add('hidden'),650)
});
  /* ========================================================
     V17 — ZIVO PLAYER SYSTEM
  ======================================================== */
  const PLAYER_KEY='zivozone_player_v17';
  const PLAYER_DEFAULT={
    level:1,totalXP:0,bestScore:0,bestStreak:0,gamesPlayed:0,
    questionsAnswered:0,timedOut:0,
    stats:{intelligence:0,speed:0,focus:0,memory:0,courage:0},
    history:[],daily:{date:'',done:false}
  };
  function cloneDefault(){return JSON.parse(JSON.stringify(PLAYER_DEFAULT))}
  function getPlayer(){
    try{
      const raw=JSON.parse(localStorage.getItem(PLAYER_KEY)||'null');
      const p=Object.assign(cloneDefault(),raw||{});
      p.stats=Object.assign({},PLAYER_DEFAULT.stats,raw?.stats||{});
      p.history=Array.isArray(raw?.history)?raw.history:[];
      p.daily=Object.assign({},PLAYER_DEFAULT.daily,raw?.daily||{});
      return p;
    }catch(e){return cloneDefault()}
  }
  function savePlayer(p){
    localStorage.setItem(PLAYER_KEY,JSON.stringify(p));
    window.dispatchEvent(new CustomEvent('zivo:player-updated',{detail:p}));
  }
  function xpForLevel(level){return Math.round(100*Math.pow(Math.max(1,level),1.22))}
  function recalcLevel(p){
    let level=1;
    while(level<100 && p.totalXP>=xpForLevel(level+1)) level++;
    p.level=level; return p;
  }
  function addPlayerProgress(result){
    const p=getPlayer();
    const score=Number(result.score)||0, speed=Number(result.speedScore)||0;
    const streak=Number(result.bestStreak)||0, timeout=Number(result.timedOut)||0;
    const xp=Math.min(250,Math.max(5,Math.round(score*.35)+Math.round(speed*.08)+Math.min(40,streak*2)+Math.max(0,20-timeout*3)));
    p.totalXP+=xp;p.gamesPlayed++;p.questionsAnswered+=Number(result.questions)||0;p.timedOut+=timeout;
    p.bestScore=Math.max(p.bestScore,score);p.bestStreak=Math.max(p.bestStreak,streak);
    const map={iq:'intelligence',science:'intelligence',math:'intelligence',memory:'memory',reaction:'speed',focus:'focus',sports:'focus',horror:'courage',identity:'focus'};
    const stat=map[result.id]; if(stat)p.stats[stat]=Math.min(100,(p.stats[stat]||0)+Math.max(1,Math.round(xp/18)));
    p.history.unshift({id:result.id||'challenge',score,xp,streak,speedScore:speed,timedOut:timeout,at:new Date().toISOString()});
    p.history=p.history.slice(0,30);recalcLevel(p);savePlayer(p);return {xp,player:p};
  }
  function playerTitle(p){return p.level>=80?'ZIVO LEGEND':p.level>=50?'MASTER':p.level>=30?'ELITE':p.level>=15?'HUNTER':p.level>=5?'RISING':'ROOKIE'}
  function playerCard(){
    const p=getPlayer(),next=p.level<100?xpForLevel(p.level+1):p.totalXP,current=p.level===1?0:xpForLevel(p.level);
    const progress=p.level>=100?100:Math.max(0,Math.min(100,((p.totalXP-current)/(next-current))*100));
    return `<section class="zivo-player-card"><div class="zivo-player-top"><div><span class="eyebrow">ZIVO PLAYER</span><h2>LEVEL ${p.level}</h2><p>${playerTitle(p)}</p></div><div class="zivo-player-badge">⚡ ${p.totalXP} XP</div></div><div class="zivo-xp-track"><span style="width:${progress}%"></span></div><div class="zivo-player-stats"><span>🏆 ${p.bestScore}</span><span>🔥 ${p.bestStreak}</span><span>🎮 ${p.gamesPlayed}</span></div><div class="zivo-skill-grid">${[['🧠','Intelligence','intelligence'],['⚡','Speed','speed'],['🎯','Focus','focus'],['🧩','Memory','memory'],['👻','Courage','courage']].map(x=>`<div><b>${x[0]}</b><span>${x[1]}</span><strong>${p.stats[x[2]]}</strong></div>`).join('')}</div></section>`
  }
  function openPlayerProfile(){
    if(typeof openModal!=='function')return;
    const p=getPlayer();
    openModal(`${playerCard()}<div class="zivo-history"><h3>Recent Runs</h3>${p.history.length?p.history.slice(0,8).map(h=>`<div class="zivo-history-row"><span>${esc(h.id)}</span><b>${h.score}</b><span>+${h.xp} XP</span><small>${new Date(h.at).toLocaleDateString()}</small></div>`).join(''):'<p class="muted">Play a challenge to build your history.</p>'}</div><button class="btn btn-ghost" id="close-player">Close</button>`,'player-profile-modal');
    document.getElementById('close-player')?.addEventListener('click',closeModal);
  }
  function isDailyAvailable(){const p=getPlayer(),d=new Date().toISOString().slice(0,10);return p.daily.date!==d||!p.daily.done}
  function markDailyDone(){const p=getPlayer();p.daily={date:new Date().toISOString().slice(0,10),done:true};savePlayer(p)}
  window.ZIVOZONE_PLAYER={get:getPlayer,save:savePlayer,recalc:recalcLevel,addProgress:addPlayerProgress,open:openPlayerProfile,isDailyAvailable,markDailyDone};

})();
