/* ZIVOZONE — audio.js
   Cinematic Web Audio engine (ambient tracks, horror stingers, SFX)
   Extracted verbatim from the former core/runtime.js monolith (V1180 refactor). No logic changed.
*/
/* ===== audio.js ===== */
/* ZIVOZONE CINEMATIC AUDIO V11
   Challenge-only music. No background audio on the home page.
   Uses local licensed project audio plus Web Audio spatial effects.
*/
(() => {
  'use strict';
  const KEY='zivozone_audio_v11';
  let enabled=true, volume=.9, ctx=null, master=null, compressor=null, input=null;
  let activeMode=null, started=false, media=null, mediaGain=null, mediaPan=null;
  let timers=[], nodes=[];
  const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
  try{const x=JSON.parse(localStorage.getItem(KEY)||'{}');if(typeof x.enabled==='boolean')enabled=x.enabled;if(Number.isFinite(x.volume))volume=clamp(x.volume,.05,1)}catch(e){}
  function save(){try{localStorage.setItem(KEY,JSON.stringify({enabled,volume}))}catch(e){}}
  function ensure(){if(ctx)return ctx;const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return null;ctx=new AC();input=ctx.createGain();compressor=ctx.createDynamicsCompressor();compressor.threshold.value=-18;compressor.knee.value=24;compressor.ratio.value=10;compressor.attack.value=.004;compressor.release.value=.2;master=ctx.createGain();master.gain.value=enabled?volume:0;input.connect(compressor);compressor.connect(master);master.connect(ctx.destination);return ctx}
  async function unlock(){const c=ensure();if(c?.state==='suspended')try{await c.resume()}catch(e){}if(media&&media.paused&&enabled)try{await media.play()}catch(e){}}
  function connect(node,pan=0){const c=ensure();if(!c||!node)return;const p=c.createStereoPanner?c.createStereoPanner():null;if(p){p.pan.value=clamp(pan,-1,1);node.connect(p);p.connect(input)}else node.connect(input)}
  function tone(freq,dur=.15,gain=.06,type='sine',pan=0,endFreq){const c=ensure();if(!c||!enabled)return;const t=c.currentTime,o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.setValueAtTime(Math.max(20,freq),t);if(endFreq)o.frequency.exponentialRampToValueAtTime(Math.max(20,endFreq),t+dur);g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(gain,t+.02);g.gain.exponentialRampToValueAtTime(.0001,t+dur);o.connect(g);connect(g,pan);o.start(t);o.stop(t+dur+.04)}
  function noise(dur=.4,gain=.03,filter=900,pan=0){const c=ensure();if(!c||!enabled)return;const n=c.createBufferSource(),b=c.createBuffer(1,Math.max(1,Math.floor(c.sampleRate*dur)),c.sampleRate),d=b.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;n.buffer=b;const f=c.createBiquadFilter(),g=c.createGain();f.type='lowpass';f.frequency.value=filter;g.gain.setValueAtTime(gain,c.currentTime);g.gain.exponentialRampToValueAtTime(.0001,c.currentTime+dur);n.connect(f);f.connect(g);connect(g,pan);n.start();n.stop(c.currentTime+dur+.02)}
  const FILES={
    iq:'assets/audio/iq_ambient.mp3',science:'assets/audio/science_ambient.mp3',daily:'assets/audio/daily_ambient.mp3',football:'assets/audio/football_ambient.mp3',logic:'assets/audio/logic_ambient.mp3',memory:'assets/audio/memory_ambient.mp3',strategy:'assets/audio/strategy_ambient.mp3',math:'assets/audio/math_ambient.mp3',reaction:'assets/audio/reaction_ambient.mp3',horror:'assets/audio/horror_ambient.mp3'
  };
  const GAIN={iq:.55,science:.5,daily:.55,football:.5,logic:.52,memory:.5,strategy:.48,math:.5,reaction:.5,horror:.86};
  function stopMedia(){if(media){try{media.pause();media.currentTime=0}catch(e){}media.remove();media=null}mediaGain=null;mediaPan=null}
  async function playAmbient(mode){stopMedia();if(!enabled||!FILES[mode])return;const c=ensure();if(!c)return;media=document.createElement('audio');media.src=FILES[mode];media.loop=true;media.preload='auto';media.volume=1;media.setAttribute('aria-hidden','true');media.style.display='none';document.body.appendChild(media);const src=c.createMediaElementSource(media);mediaGain=c.createGain();mediaGain.gain.value=GAIN[mode]||.5;mediaPan=c.createStereoPanner?c.createStereoPanner():null;if(mediaPan){mediaPan.pan.value=0;src.connect(mediaGain);mediaGain.connect(mediaPan);mediaPan.connect(input)}else{src.connect(mediaGain);mediaGain.connect(input)}try{await media.play()}catch(e){} }
  function spatialSweep(){if(!mediaPan||!ctx||!enabled)return;const t=ctx.currentTime;mediaPan.pan.cancelScheduledValues(t);mediaPan.pan.setValueAtTime(-.75,t);mediaPan.pan.linearRampToValueAtTime(.72,t+4.2);mediaPan.pan.linearRampToValueAtTime(-.55,t+8.4)}
  function eerieLaugh(){if(activeMode!=='horror'||!enabled)return;[0,.18,.36,.58].forEach((d,i)=>setTimeout(()=>{tone(95+i*11,.18,.095,'sawtooth',i%2?-.7:.7,145+i*15)},d*1000))}
  function distantScream(){if(activeMode!=='horror'||!enabled)return;const c=ensure();if(!c)return;const t=c.currentTime,o=c.createOscillator(),g=c.createGain(),p=c.createStereoPanner?c.createStereoPanner():null;o.type='sawtooth';o.frequency.setValueAtTime(210,t);o.frequency.exponentialRampToValueAtTime(720,t+1.1);o.frequency.exponentialRampToValueAtTime(130,t+1.65);g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.16,t+.15);g.gain.exponentialRampToValueAtTime(.04,t+1.1);g.gain.exponentialRampToValueAtTime(.0001,t+1.65);o.connect(g);if(p){p.pan.setValueAtTime(Math.random()>.5?-.95:.95,t);p.pan.linearRampToValueAtTime(Math.random()>.5?.75:-.75,t+1.6);g.connect(p);p.connect(input)}else g.connect(input);o.start(t);o.stop(t+1.7)}
  function horrorPulse(level=1){if(activeMode!=='horror')return;tone(55-level*3,.5,.14,'sawtooth',Math.random()>.5?.9:-.9,24);noise(.4,.08,240,Math.random()>.5?.9:-.9)}
  function phase(level=1){if(activeMode!=='horror')return;horrorPulse(level);if(level>=2){tone(34,.9,.15,'sawtooth',-.7,20);tone(48,.8,.11,'sine',.7,24)}if(level>=3){noise(1.6,.13,260,-.85);noise(1.6,.13,260,.85);distantScream()}}
  function question(d){if(!started||!enabled)return;if(activeMode==='horror'){tone(Math.max(25,78-d*3),.45,.12,'sawtooth',Math.random()>.5?.8:-.8,25);if(d>=7)noise(.5,.06,220,Math.random()>.5?.9:-.9);return}const f=Math.max(60,400-d*22);tone(f,.1,.045,activeMode==='reaction'?'square':'triangle',Math.random()>.5?.4:-.4,f*1.35)}
  function click(){if(!started)return;tone(activeMode==='horror'?170:500,.06,.07,activeMode==='reaction'?'square':'triangle',Math.random()>.5?.25:-.25)}
  function tick(){if(!started||!enabled)return;tone(activeMode==='horror'?260:760,.055,.028,'sine',0,activeMode==='horror'?210:620)}
  function timeout(){if(!started||!enabled)return;if(activeMode==='horror'){tone(48,.35,.11,'sawtooth',0,24);noise(.3,.06,180,Math.random()>.5?.8:-.8)}else{tone(120,.16,.055,'triangle',0,70)}}
  function correct(){if(activeMode==='horror')return;tone(680,.11,.06,'sine',0,950);tone(950,.13,.04,'triangle',.1,1200)}
  function wrong(){if(activeMode==='horror')return;tone(115,.2,.075,'sawtooth',0,52);noise(.16,.025,450)}
  function success(){tone(420,.12,.05,'triangle');tone(620,.16,.05,'triangle',.1,900);tone(900,.22,.05,'sine',-.1,1200)}
  function scaryVoice(text='لا تخرج... أنا أراك.'){if(activeMode!=='horror'||!enabled)return;if('speechSynthesis' in window){try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang=(document.documentElement.lang||'ar')==='ar'?'ar-SA':'en-US';u.rate=.62;u.pitch=.18;u.volume=Math.min(1,volume*.95);speechSynthesis.speak(u)}catch(e){}}tone(42,.9,.12,'sawtooth',-.5,24);tone(31,1.2,.1,'sine',.5,18);noise(.8,.08,260,Math.random()>.5?.8:-.8)}
  function warden(){if(activeMode!=='horror'||!enabled)return;scaryVoice((document.documentElement.lang||'ar')==='ar'?'لا تخرج... أنا أسمعك.':'Do not leave... I can hear you.')}
  function whisper(){if(activeMode!=='horror'||!enabled)return;scaryVoice((document.documentElement.lang||'ar')==='ar'?'لا أحد هنا... أليس كذلك؟':'No one is here... right?')}
  function checkpoint(){if(activeMode!=='horror'||!enabled)return;horrorPulse(4);tone(25,1.3,.14,'sawtooth',0,16);noise(1.2,.1,180,0)}
  function horrorAnswer(d){if(activeMode!=='horror'||!enabled)return;noise(.25,.045,190,Math.random()>.5?.9:-.9);if(d>=7)tone(28,.7,.1,'sawtooth',Math.random()>.5?.7:-.7,17)}
  function startChallenge(mode){unlock();stopChallenge();activeMode=mode;started=true;playAmbient(mode);const profile={iq:[72,108],science:[118,176],daily:[300,420],football:[82,124],logic:[55,84],memory:[170,255],strategy:[48,72],math:[132,198],reaction:[440,650],horror:[34,51]}[mode]||[72,108];if(enabled){tone(profile[0],.3,.025,'sine',-.35);tone(profile[1],.25,.018,'triangle',.35)}if(mode==='horror'){tone(22,.4,.07,'sine',0);timers.push(setInterval(()=>{if(activeMode!=='horror'||!enabled)return;spatialSweep();noise(1.2,.035,180,Math.sin(Date.now()/1400)*.8);if(Math.random()<.16)eerieLaugh();if(Math.random()<.055)distantScream();if(Math.random()<.035)scaryVoice()},5000));timers.push(setInterval(()=>{if(activeMode!=='horror'||!enabled)return;horrorPulse(Math.min(5,1+Math.floor((Date.now()/1000)%30/6)))},3700))}else{timers.push(setInterval(()=>{if(!enabled||!started)return;spatialSweep();const pan=Math.sin(Date.now()/1800)*.6;tone(profile[0],.5,.022,mode==='reaction'?'square':'sine',pan,profile[1]);noise(.25,.016,mode==='reaction'?1900:1000,-pan*.4)},2400))}}
  function stopChallenge(){timers.forEach(clearInterval);timers=[];stopMedia();nodes.forEach(n=>{try{n.stop()}catch(e){}});nodes=[];if('speechSynthesis' in window)try{speechSynthesis.cancel()}catch(e){}activeMode=null;started=false}
  function setEnabled(v){enabled=!!v;ensure();if(master)master.gain.setTargetAtTime(enabled?volume:0,ctx.currentTime,.08);if(!enabled)stopChallenge();save()}
  function setVolume(v){volume=clamp(Number(v),.05,1);ensure();if(master)master.gain.setTargetAtTime(enabled?volume:0,ctx.currentTime,.08);save()}
  function narrate(text){if(activeMode!=='horror'||!text||!('speechSynthesis' in window))return;try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang=(document.documentElement.lang||'ar')==='ar'?'ar-SA':'en-US';u.rate=.78;u.pitch=.48;u.volume=clamp(volume*.72,.15,.8);speechSynthesis.speak(u)}catch(e){}}
  window.ZIVOZONE_AUDIO={unlock,setEnabled,isEnabled:()=>enabled,toggle:()=>setEnabled(!enabled),setVolume,volume:()=>volume,click,tick,timeout,correct,wrong,success,question,startChallenge,stopChallenge,horrorPulse,phase,checkpoint,narrate,warden,whisper,horrorAnswer,active:()=>started};
})();
