/* ZIVOZONE — engagement.js
   Account-scoped active-time engagement tracker
   Extracted verbatim from the former core/runtime.js monolith (V1180 refactor). No logic changed.
*/
/* ============================================================
   ZIVOZONE V85 — ACCOUNT-SCOPED ENGAGEMENT
   Active visible time per signed-in user; idle sessions do not count.
============================================================ */
(function(){'use strict';
  const IDLE=90*1000,TIER=10*60,BASE='zivozone_engagement_v85';
  const uid=()=>window.firebase?.auth?.()?.currentUser?.uid||'guest';
  const key=()=>`${BASE}:${uid()}`;
  const read=()=>{try{return JSON.parse(localStorage.getItem(key())||'{}')}catch(e){return{}}};
  const write=v=>{try{localStorage.setItem(key(),JSON.stringify(v))}catch(e){}};
  let s={activeSeconds:0,lastTick:Date.now(),lastActivity:Date.now(),claimedTiers:0,lastSync:0,...read()};
  const activity=()=>{s.lastActivity=Date.now()};
  ['pointermove','pointerdown','keydown','touchstart','scroll'].forEach(e=>addEventListener(e,activity,{passive:true}));
  function tick(){const now=Date.now();const dt=Math.max(0,Math.min(15,(now-(s.lastTick||now))/1000));s.lastTick=now;if(document.visibilityState==='visible'&&now-s.lastActivity<=IDLE){s.activeSeconds+=dt;write(s)}}
  function activeMinutes(){return Math.floor(s.activeSeconds/60)}
  function claimableBonus(){return Math.max(0,Math.min(10,Math.floor(s.activeSeconds/TIER)-Number(s.claimedTiers||0)))}
  function markBonusClaimed(n){s.claimedTiers=Math.min(10,(Number(s.claimedTiers)||0)+Math.max(0,Number(n)||0));write(s)}
  async function sync(){const u=window.firebase?.auth?.()?.currentUser,d=window.firebase?.firestore?.();if(!u||!d)return false;try{const now=d.FieldValue?.serverTimestamp?d.FieldValue.serverTimestamp():firebase.firestore.FieldValue.serverTimestamp();await Promise.all([d.collection('users').doc(u.uid).set({engagement:{activeSeconds:Math.floor(s.activeSeconds),activeMinutes:activeMinutes(),updatedAt:now}},{merge:true}),d.collection('players').doc(u.uid).set({activeSeconds:Math.floor(s.activeSeconds),activeMinutes:activeMinutes(),engagementUpdatedAt:now},{merge:true})]);s.lastSync=Date.now();write(s);return true}catch(e){return false}}
  function reset(){s={activeSeconds:0,lastTick:Date.now(),lastActivity:Date.now(),claimedTiers:0,lastSync:0};write(s)}
  window.ZIVOZONE_ENGAGEMENT={activeSeconds:()=>Math.floor(s.activeSeconds),activeMinutes,claimableBonus,markBonusClaimed,sync,reset};
  setInterval(tick,5000);addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')activity();sync()});addEventListener('online',sync);addEventListener('zivozone-auth',()=>{s={activeSeconds:0,lastTick:Date.now(),lastActivity:Date.now(),claimedTiers:0,lastSync:0,...read()};sync()});setTimeout(sync,2500);
})();
