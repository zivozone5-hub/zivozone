/* ZIVOZONE CLEAN CORE — centralized runtime configuration */
(() => {
  'use strict';
  const existing = window.ZIVOZONE_CONFIG || {};
  window.ZIVOZONE_CONFIG = Object.freeze({
    ...existing,
    APP_NAME: 'ZIVOZONE',
    APP_VERSION: '1180',
    CORE_VERSION: '1180-maintenance-core',
    ADMIN_EMAIL: 'raefalbtish@gmail.com',
    ADMIN_EMAIL_NORMALIZED: 'raefalbtish@gmail.com',
    FREE_FIRST: true,
    MINING_COOLDOWN_MS: 24 * 60 * 60 * 1000,
    SPORTS_API_BASE: 'https://site.api.espn.com/apis/site/v2/sports/soccer/',
    SPORTS_STATIC_BASE: './data/matches/',
    SPORTS_FREE_DB_BASE: 'https://www.thesportsdb.com/api/v1/json/123/'
  });
})();
