/* ZIVOZONE V1180 CORE — CENTRAL STATE
   Single ZIVOZONE.State object per spec §4, holding: auth, player, economy,
   wallet, mining, challenge, missions, achievements, sports, news, ui, admin.

   Non-invasive by design: existing modules (auth.js, player.js, economy.js,
   match-center.js, ...) keep their own internal state and public globals
   exactly as before — nothing is removed. This store is a read layer other
   code (new UI, Admin Control Center, future modules) can subscribe to
   instead of reaching into module internals. Modules opt in to publishing
   here by calling ZIVOZONE.State.set(slice, patch); existing modules that
   have not been migrated yet simply don't populate their slice yet, and
   ui.get() safely returns {} for those until migrated.
*/
(() => {
  'use strict';

  const SLICES = ['auth', 'player', 'economy', 'wallet', 'mining', 'challenge',
    'missions', 'achievements', 'sports', 'news', 'ui', 'admin'];

  const store = {};
  SLICES.forEach(k => { store[k] = {}; });

  const subscribers = new Map(); // slice -> Set<fn>

  function get(slice) {
    if (!slice) return { ...store };
    return store[slice] ? { ...store[slice] } : {};
  }

  function set(slice, patch) {
    if (!SLICES.includes(slice)) {
      console.warn(`[ZIVOZONE.State] unknown slice "${slice}" — add it to SLICES if this is intentional.`);
      return;
    }
    store[slice] = { ...store[slice], ...patch };
    subscribers.get(slice)?.forEach(fn => {
      try { fn(store[slice]); } catch (err) { console.error(`[ZIVOZONE.State] subscriber failed for ${slice}`, err); }
    });
    window.ZIVOZONE?.Events?.emit?.(`${slice.toUpperCase()}_UPDATED`, store[slice]);
  }

  function subscribe(slice, fn) {
    if (!subscribers.has(slice)) subscribers.set(slice, new Set());
    subscribers.get(slice).add(fn);
    return () => subscribers.get(slice)?.delete(fn);
  }

  window.ZIVOZONE = window.ZIVOZONE || {};
  window.ZIVOZONE.State = Object.freeze({ get, set, subscribe, SLICES });
})();
