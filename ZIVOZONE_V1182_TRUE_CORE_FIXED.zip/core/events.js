/* ZIVOZONE V1180 CORE — EVENT BUS
   Central publish/subscribe bus so domain modules (Challenges, Economy,
   Player, Sports, News, ...) can react to each other's events without being
   wired directly together file-to-file.

   Non-invasive by design: this module does not remove or replace any
   existing window.CustomEvent / window.dispatchEvent usage already present
   in V1180/V1180 modules. It adds a lightweight bus on top that new and
   gradually-migrated code can use. Existing DOM CustomEvents keep working.
*/
(() => {
  'use strict';

  const listeners = new Map(); // eventName -> Set<fn>
  const history = [];          // last N events, for System Health / Event Log (spec §43)
  const HISTORY_LIMIT = 200;

  // Canonical event names (spec §5). Not enforced — informative registry so
  // modules can discover what already exists instead of inventing near-duplicates.
  const KNOWN_EVENTS = Object.freeze([
    'AUTH_CHANGED', 'PLAYER_UPDATED', 'WALLET_UPDATED', 'MINING_COMPLETED',
    'CHALLENGE_STARTED', 'CHALLENGE_COMPLETED', 'REWARD_GRANTED',
    'MISSION_UPDATED', 'ACHIEVEMENT_UNLOCKED', 'MATCH_UPDATED',
    'NEWS_UPDATED', 'API_ERROR'
  ]);

  function on(eventName, handler) {
    if (typeof handler !== 'function') return () => {};
    if (!listeners.has(eventName)) listeners.set(eventName, new Set());
    listeners.get(eventName).add(handler);
    return () => off(eventName, handler);
  }

  function once(eventName, handler) {
    const unsub = on(eventName, (...args) => { unsub(); handler(...args); });
    return unsub;
  }

  function off(eventName, handler) {
    listeners.get(eventName)?.delete(handler);
  }

  function emit(eventName, detail) {
    history.push({ eventName, detail, at: Date.now() });
    if (history.length > HISTORY_LIMIT) history.shift();

    const set = listeners.get(eventName);
    if (set) {
      // Copy to array: a handler unsubscribing mid-emit must not skip siblings.
      Array.from(set).forEach(fn => {
        try { fn(detail, eventName); }
        catch (err) { console.error(`[ZIVOZONE.Events] handler failed for ${eventName}`, err); }
      });
    }

    // Bridge outward to the DOM so legacy code listening via
    // window.addEventListener('zivozone:<event>', ...) keeps working.
    try {
      window.dispatchEvent(new CustomEvent(`zivozone:${eventName.toLowerCase()}`, { detail }));
    } catch (_) { /* non-fatal */ }
  }

  function getHistory(eventName) {
    return eventName ? history.filter(h => h.eventName === eventName) : history.slice();
  }

  window.ZIVOZONE = window.ZIVOZONE || {};
  window.ZIVOZONE.Events = Object.freeze({
    on, once, off, emit,
    getHistory,
    KNOWN_EVENTS
  });
})();
