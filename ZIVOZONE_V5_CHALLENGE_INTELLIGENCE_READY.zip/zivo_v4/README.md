# ZIVOZONE V5 — Challenge Intelligence Build

This build keeps the previous ZIVOZONE architecture and adds a larger challenge pool without changing the Firebase project configuration.

## Included
- index.html
- styles.css
- app.js
- auth.js
- challenges.js
- i18n.js
- audio.js
- firestore.rules

## Challenge system
- IQ: 20-question pool -> 10-question session
- Science: 20-question pool -> 10-question session
- Daily: 20-question pool -> 10-question session
- Dark Room: 20-question pool -> 10-question session
- Football: 10-question tactical session
- Every session is ordered from easier to harder.
- Larger pools remember recent question IDs locally to reduce repetition.
- All challenge content is localized in Arabic, English, Chinese, Hindi and Spanish.

## Firebase
Keep the existing Firebase configuration in index.html.
Publish firestore.rules in Firebase Console > Firestore Database > Rules.
The rules use `players/{uid}` as the ownership boundary and `players/{uid}/results` for private results.

## Upload
Replace the existing files in the GitHub Pages repository with these files. Do not rename the files.
