(() => {
"use strict";
const KEY="zivozone_account_v3";
let user=null, player=null, ready=false, db=null, cloud=false;
const cfg=window.ZIVOZONE_FIREBASE_CONFIG;
function emit(){window.dispatchEvent(new CustomEvent("zivozone-auth",{detail:{user,player,ready,cloud}}));}
function localLoad(){try{const x=JSON.parse(localStorage.getItem(KEY)||"null");if(x?.user){user=x.user;player=x.player||defaultPlayer(user);}}catch(e){console.warn(e)}}
function save(){localStorage.setItem(KEY,JSON.stringify({user,player}));}
function defaultPlayer(u){return {uid:u.uid,name:u.name||"لاعب ZIVO",age:Number(u.age)||18,email:u.email,level:1,xp:0,coins:0,wins:0,gamesPlayed:0,language:"ar"}}
async function initCloud(){
if(!cfg||!window.firebase)return false;
try{
if(!firebase.apps.length)firebase.initializeApp(cfg);
db=firebase.firestore(); const auth=firebase.auth(); cloud=true;
auth.onAuthStateChanged(async u=>{if(!u){user=null;player=null;emit();return}
user={uid:u.uid,email:u.email};let s=await db.collection("players").doc(u.uid).get();player=s.exists?{uid:u.uid,...s.data()}:defaultPlayer(user);emit();});
return true;
}catch(e){console.error("Firebase:",e);cloud=false;return false}
}
async function register(data){
const name=String(data.name||"").trim(),email=String(data.email||"").trim().toLowerCase(),password=String(data.password||""),age=Number(data.age);
if(name.length<2)throw Error("اكتب اسم اللاعب.");
if(!Number.isInteger(age)||age<5||age>100)throw Error("العمر يجب أن يكون بين 5 و100.");
if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw Error("البريد الإلكتروني غير صحيح.");
if(password.length<6)throw Error("كلمة المرور يجب أن تكون 6 أحرف على الأقل.");
if(cloud){
const r=await firebase.auth().createUserWithEmailAndPassword(email,password),u=r.user;
await db.collection("players").doc(u.uid).set({...defaultPlayer({uid:u.uid,email,name,age}),createdAt:firebase.firestore.FieldValue.serverTimestamp()});
user={uid:u.uid,email};player=defaultPlayer({uid:u.uid,email,name,age});emit();return player;
}
let accounts=JSON.parse(localStorage.getItem("zivozone_accounts")||"{}");
if(accounts[email])throw Error("هذا البريد مستخدم مسبقًا.");
accounts[email]={name,age,email,password};localStorage.setItem("zivozone_accounts",JSON.stringify(accounts));
user={uid:"local_"+btoa(unescape(encodeURIComponent(email))).replace(/=/g,""),email,name,age};player=defaultPlayer(user);save();emit();return player;
}
async function login(email,password){
email=String(email||"").trim().toLowerCase();password=String(password||"");
if(cloud){await firebase.auth().signInWithEmailAndPassword(email,password);return player;}
const accounts=JSON.parse(localStorage.getItem("zivozone_accounts")||"{}"),a=accounts[email];
if(!a||a.password!==password)throw Error("البريد أو كلمة المرور غير صحيحة.");
user={uid:"local_"+btoa(unescape(encodeURIComponent(email))).replace(/=/g,""),email:a.email,name:a.name,age:a.age};player=defaultPlayer(user);
const old=JSON.parse(localStorage.getItem(KEY)||"null");if(old?.player?.email===email)player=old.player;save();emit();return player;
}
async function logout(){if(cloud)await firebase.auth().signOut();user=null;player=null;localStorage.removeItem(KEY);emit();}
async function update(patch){
if(!player)throw Error("يجب تسجيل الدخول أولًا.");
player={...player,...patch};save();
if(cloud&&db)await db.collection("players").doc(player.uid).set(patch,{merge:true});
emit();return player;
}
function getUser(){return user} function getPlayer(){return player} function isLoggedIn(){return !!user}
window.ZIVOZONE_AUTH={register,login,logout,update,getUser,getPlayer,isLoggedIn,init:async()=>{localLoad();await initCloud();ready=true;emit();}};
window.ZIVOZONE_AUTH.init();
})();