(() => {
"use strict";
const A=window.ZIVOZONE_AUTH, $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const LS="zivozone_state_v4";
let state={level:1,xp:0,coins:0,wins:0,gamesPlayed:0,identity:{},daily:null};
let game={type:null,questions:[],index:0,score:0};
const Q={
quiz:[
["ما العدد التالي: 2، 4، 8، 16، ؟",["20","24","32","36"],2],
["أي كلمة مختلفة؟",["تفاحة","موزة","سيارة","برتقالة"],2],
["إذا كان اليوم الاثنين، فما اليوم بعد 10 أيام؟",["الأربعاء","الخميس","الخميس","السبت"],1],
["ما نصف 50؟",["15","20","25","30"],2],
["أي رقم أولي؟",["9","15","17","21"],2]],
science:[
["ما الكوكب المعروف بالكوكب الأحمر؟",["الأرض","المريخ","الزهرة","المشتري"],1],
["ما الغاز الضروري للتنفس عند الإنسان؟",["الأكسجين","الهيليوم","الهيدروجين","النيون"],0],
["كم عدد قارات العالم؟",["5","6","7","8"],2],
["ما أقرب نجم إلى الأرض؟",["القمر","الشمس","الشعرى","القطب"],1],
["أي عضو يضخ الدم؟",["الرئة","الكبد","القلب","المعدة"],2]],
daily:[["كم يساوي 15 + 27؟",["32","42","52","62"],1],["ما عاصمة الأردن؟",["عمّان","إربد","العقبة","الزرقاء"],0],["كم عدد أيام الأسبوع؟",["5","6","7","8"],2]]
};
const SPORTS=[
["⚽","كرة القدم","نتائج ومنافسات كرة القدم العالمية."],
["🏀","كرة السلة","أبرز أخبار ومباريات كرة السلة."],
["🎾","التنس","بطولات ونتائج التنس."],
["🏆","بطولات","اكتشف عالم المنافسات الرياضية."]
];
function toast(msg,type="info"){const box=$("#toast-container"),x=document.createElement("div");x.className="toast "+type;x.textContent=msg;box.appendChild(x);setTimeout(()=>x.remove(),3500)}
function esc(s){const d=document.createElement("div");d.textContent=s;return d.innerHTML}
function level(){return Math.floor(state.xp/100)+1}
function save(){localStorage.setItem(LS,JSON.stringify(state))}
function syncPlayer(){const p=A.getPlayer();if(!p)return;state={...state,level:p.level||level(),xp:p.xp||0,coins:p.coins||0,wins:p.wins||0,gamesPlayed:p.gamesPlayed||0};save()}
function profile(){
const p=A.getPlayer(),l=level(),base=(l-1)*100,progress=Math.min(100,((state.xp-base)/100)*100);
$("#profile-name").textContent=p?.name||"زائر";$("#profile-email").textContent=p?.email||"سجل حسابك لحفظ تقدمك.";
$("#profile-level").textContent=l;$("#profile-xp").textContent=state.xp;$("#profile-coins").textContent=state.coins;$("#profile-wins").textContent=state.wins;$("#player-level-chip").textContent="Level "+l;$("#xp-progress").style.width=progress+"%";
$("#logout-btn").hidden=!A.isLoggedIn();$("#login-btn").textContent=A.isLoggedIn()?"👤 "+(p?.name||"حسابي"):"🔐 إنشاء حساب / دخول";
}
async function reward(xp,coins=1,win=true){state.xp+=xp;state.coins+=coins;if(win)state.wins++;state.gamesPlayed++;save();if(A.isLoggedIn())await A.update({xp:state.xp,coins:state.coins,wins:state.wins,gamesPlayed:state.gamesPlayed,level:level()});profile()}
function requireAuth(action){if(A.isLoggedIn()){action();return}openAuth(action)}
function openModal(html){const r=$("#modal-root");r.innerHTML=`<div class="modal-backdrop"><div class="modal-card">${html}</div></div>`;r.setAttribute("aria-hidden","false");r.onclick=e=>{if(e.target.classList.contains("modal-backdrop"))closeModal()}}
function closeModal(){$("#modal-root").innerHTML="";$("#modal-root").setAttribute("aria-hidden","true")}
function openAuth(after){
openModal(`<button class="modal-close" data-close>×</button><div class="modal-head"><span class="eyebrow">ZIVO ACCOUNT</span><h2 id="auth-title">مرحبًا بك في ZIVOZONE</h2><p id="auth-sub">أنشئ حسابك مجانًا واحفظ تقدمك.</p></div><div class="auth-tabs"><button class="btn btn-primary" id="tab-register">إنشاء حساب</button><button class="btn btn-ghost" id="tab-login">تسجيل الدخول</button></div><form id="auth-form"><div id="name-wrap"><input id="auth-name" placeholder="اسم اللاعب" minlength="2"></div><div id="age-wrap"><input id="auth-age" type="number" min="5" max="100" placeholder="العمر"></div><input id="auth-email" type="email" required placeholder="البريد الإلكتروني"><input id="auth-pass" type="password" minlength="6" required placeholder="كلمة المرور"><button class="btn btn-primary full" id="auth-submit">إنشاء الحساب والبدء</button></form><p class="muted">يمكن تشغيل النسخة التجريبية محليًا، ومع Firebase تعمل الحسابات السحابية عند وضع إعدادات المشروع.</p>`);
let mode="register";const setMode=m=>{mode=m;$("#name-wrap").hidden=m==="login";$("#age-wrap").hidden=m==="login";$("#auth-submit").textContent=m==="login"?"تسجيل الدخول":"إنشاء الحساب والبدء";$("#tab-register").className="btn "+(m==="register"?"btn-primary":"btn-ghost");$("#tab-login").className="btn "+(m==="login"?"btn-primary":"btn-ghost")};
$("#tab-register").onclick=()=>setMode("register");$("#tab-login").onclick=()=>setMode("login");$("#auth-form").onsubmit=async e=>{e.preventDefault();try{if(mode==="register")await A.register({name:$("#auth-name").value,age:$("#auth-age").value,email:$("#auth-email").value,password:$("#auth-pass").value});else await A.login($("#auth-email").value,$("#auth-pass").value);closeModal();profile();toast("تم تسجيل الدخول بنجاح","success");if(after)after()}catch(err){toast(err.message||"حدث خطأ","error")}};
$$("[data-close]").forEach(x=>x.onclick=closeModal)
}
function startQuiz(type){
const source=Q[type]||Q.quiz;game={type,questions:[...source].sort(()=>Math.random()-.5),index:0,score:0};renderQuestion()
}
function renderQuestion(){
const q=game.questions[game.index];if(!q){finishGame();return}
openModal(`<button class="modal-close" data-close>×</button><span class="eyebrow">${game.type==="science"?"SCIENCE":game.type==="daily"?"DAILY":"IQ"}</span><h2>${esc(q[0])}</h2><p>السؤال ${game.index+1} من ${game.questions.length}</p><div class="answers">${q[1].map((x,i)=>`<button class="btn btn-ghost answer" data-i="${i}">${esc(x)}</button>`).join("")}</div>`);
$$(".answer").forEach(b=>b.onclick=()=>{if(+b.dataset.i===q[2])game.score++;game.index++;renderQuestion()})
}
async function finishGame(){const xp=Math.max(10,game.score*10+(game.type==="daily"?10:30));const coin=Math.max(1,Math.ceil(game.score/2));closeModal();await reward(xp,coin,true);toast(`انتهت اللعبة! +${xp} XP و +${coin} 🪙 ZIVO`,"success")}
function horror(){const scenes=[["الغرفة المظلمة","تسمع صوتًا خلف الباب. ماذا تفعل؟",["أفتح الباب","أبحث عن مخرج آخر"]],["الممر","وجدت مصباحًا وبابًا قديمًا.",["آخذ المصباح","أدخل الباب فورًا"]],["النهاية","تصل إلى باب مضيء.",["أخرج","أعود للغرفة"]]];let i=0;const step=()=>{const s=scenes[i];openModal(`<button class="modal-close" data-close>×</button><span class="eyebrow">HORROR</span><h2>${s[0]}</h2><p>${s[1]}</p><div class="answers">${s[2].map((x,n)=>`<button class="btn btn-ghost horror-choice" data-n="${n}">${x}</button>`).join("")}</div>`);$$(".horror-choice").forEach(b=>b.onclick=()=>{i++;if(i<scenes.length)step();else{closeModal();reward(75,2,true);toast("نجوت من الغرفة المظلمة! +75 XP","success")}})};step()}
function identity(){const qs=[["عندما تواجه مشكلة جديدة؟",["أحللها بهدوء","أجرب بسرعة","أسأل الآخرين"]],["في المنافسة تهمك أكثر؟",["الدقة","السرعة","الإبداع"]],["عندما تتغير الخطة؟",["أعيد التخطيط","أتكيف فورًا","أبحث عن بديل"]],["تفضل؟",["التحديات المنطقية","المغامرة","التعاون"]]];let i=0,scores=[0,0,0];const step=()=>{if(i>=qs.length){const max=scores.indexOf(Math.max(...scores)),names=["العقل المحلل 🧠","المغامر ⚡","اللاعب المتعاون 🤝"];closeModal();openModal(`<button class="modal-close" data-close>×</button><span class="eyebrow">YOUR ZIVO PROFILE</span><h2>${names[max]}</h2><p>نتيجة ترفيهية مبنية على اختياراتك داخل الاختبار.</p><button class="btn btn-primary full" data-close>إغلاق</button>`);$("#modal-root [data-close]").onclick=closeModal;return}const q=qs[i];openModal(`<button class="modal-close" data-close>×</button><span class="eyebrow">WHO AM I?</span><h2>${q[0]}</h2><div class="answers">${q[1].map((x,n)=>`<button class="btn btn-ghost id-choice" data-n="${n}">${x}</button>`).join("")}</div>`);$$(".id-choice").forEach(b=>b.onclick=()=>{scores[+b.dataset.n]++;i++;step()})};step()}
function challenges(){const done=localStorage.getItem("zivo_daily_"+new Date().toISOString().slice(0,10));$("#challenge-list").innerHTML=[["🎯","تحدي اليوم","أجب عن 3 أسئلة.","daily"],["🧠","تحدي الذكاء","حقق نتيجة كاملة في اختبار IQ.","quiz"],["👻","تحدي الشجاعة","أنهِ الغرفة المظلمة.","horror"]].map(x=>`<article class="challenge-card"><span class="challenge-icon">${x[0]}</span><div><h3>${x[1]}</h3><p>${x[2]}</p></div><button class="btn btn-primary" data-challenge="${x[3]}" ${done&&x[3]==="daily"?"disabled":""}>${done&&x[3]==="daily"?"تم اليوم":"ابدأ"}</button></article>`).join("");$$("[data-challenge]").forEach(b=>b.onclick=()=>requireAuth(()=>startGame(b.dataset.challenge)))}
function startGame(t){if(t==="horror")horror();else startQuiz(t)}
function sports(){ $("#sports-list").innerHTML=SPORTS.map(x=>`<article class="sports-card"><div class="icon">${x[0]}</div><h3>${x[1]}</h3><p>${x[2]}</p><button class="btn btn-ghost" data-action="sport-info">فتح</button></article>`).join("")}
function aiReply(q){q=q.toLowerCase();if(q.includes("مستوى")||q.includes("level"))return`مستواك الحالي ${level()} ولديك ${state.xp} XP و${state.coins} ZIVO 🪙.`;if(q.includes("لعب")||q.includes("لعبة"))return"ابدأ من قسم الألعاب، وكل فوز يزيد XP وZIVO.";if(q.includes("أنا")||q.includes("شخص"))return"جرّب اختبار «من أنا؟» وسأعطيك نمطًا ترفيهيًا بناءً على اختياراتك.";return"أنا ZIVO AI التجريبي 🤖 جرّب أن تسألني عن مستواك أو الألعاب أو التحديات."}
function bind(){
$("#login-btn").onclick=()=>A.isLoggedIn()?location.hash="#profile":openAuth();
$$("[data-action='login']").forEach(b=>b.onclick=()=>A.isLoggedIn()?location.hash="#profile":openAuth());
$$("[data-game]").forEach(b=>b.onclick=()=>requireAuth(()=>startGame(b.dataset.game)));
$$("[data-action='scroll-games']").forEach(b=>b.onclick=()=>$("#games").scrollIntoView({behavior:"smooth"}));
$$("[data-action='open-identity']").forEach(b=>b.onclick=()=>requireAuth(identity));
$$("[data-action='logout']").forEach(b=>b.onclick=async()=>{await A.logout();state={level:1,xp:0,coins:0,wins:0,gamesPlayed:0};save();profile();toast("تم تسجيل الخروج")});
$$("[data-action='refresh-sports']").forEach(b=>b.onclick=()=>{sports();toast("تم تحديث قسم الرياضة","success")});
$$("[data-action='ad-info']").forEach(b=>b.onclick=()=>toast("سيتم تفعيل الإعلانات والرعاة في مرحلة الإطلاق."));
$("#ai-form").onsubmit=e=>{e.preventDefault();const v=$("#ai-input").value.trim();if(!v)return;const box=$("#ai-messages"),u=document.createElement("div"),bot=document.createElement("div");u.className="ai-message user";u.textContent=v;bot.className="ai-message bot";bot.textContent=aiReply(v);box.append(u,bot);$("#ai-input").value="";box.scrollTop=box.scrollHeight};
}
window.addEventListener("zivozone-auth",()=>{syncPlayer();profile()});
try{state={...state,...JSON.parse(localStorage.getItem(LS)||"{}")}}catch(e){}
document.addEventListener("DOMContentLoaded",()=>{bind();challenges();sports();profile();setTimeout(()=>$("#app-loader")?.classList.add("hidden"),500)});
})();